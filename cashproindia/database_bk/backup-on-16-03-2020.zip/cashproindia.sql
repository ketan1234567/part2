#
# TABLE STRUCTURE FOR: tbl_addcapital
#

DROP TABLE IF EXISTS `tbl_addcapital`;

CREATE TABLE `tbl_addcapital` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `amount` varchar(250) DEFAULT NULL,
  `date` varchar(250) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_addcapital` (`id`, `amount`, `date`, `timestamp`) VALUES ('4', '6780', '2019-12-15', '2019-12-15 15:45:47');
INSERT INTO `tbl_addcapital` (`id`, `amount`, `date`, `timestamp`) VALUES ('5', '10000', '2019-12-03', '2020-03-08 15:21:04');


#
# TABLE STRUCTURE FOR: tbl_cashinbank
#

DROP TABLE IF EXISTS `tbl_cashinbank`;

CREATE TABLE `tbl_cashinbank` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cashinbank` varchar(250) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_cashinbank` (`id`, `cashinbank`, `timestamp`) VALUES ('1', '47700', '2019-12-05 14:39:27');


#
# TABLE STRUCTURE FOR: tbl_exp
#

DROP TABLE IF EXISTS `tbl_exp`;

CREATE TABLE `tbl_exp` (
  `tbl_exp_id` int(250) NOT NULL AUTO_INCREMENT,
  `exp_type` varchar(250) DEFAULT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `cap_type` int(250) DEFAULT NULL,
  `amount` int(250) DEFAULT NULL,
  `date` varchar(250) DEFAULT NULL,
  `tbl_exp_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tbl_exp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_exp` (`tbl_exp_id`, `exp_type`, `remark`, `cap_type`, `amount`, `date`, `tbl_exp_timestamp`) VALUES ('2', 'Stationary', 'Cash Register book and pen', '1', '180', '2019-12-13', '2019-12-15 15:42:31');
INSERT INTO `tbl_exp` (`tbl_exp_id`, `exp_type`, `remark`, `cap_type`, `amount`, `date`, `tbl_exp_timestamp`) VALUES ('3', 'Stationary', 'Cirtificates, T-shirts and Flyer', '1', '4000', '2019-12-01', '2019-12-15 15:44:04');
INSERT INTO `tbl_exp` (`tbl_exp_id`, `exp_type`, `remark`, `cap_type`, `amount`, `date`, `tbl_exp_timestamp`) VALUES ('4', 'Stationary', 'Passbook Printing', '1', '2600', '2019-12-01', '2019-12-15 15:44:49');
INSERT INTO `tbl_exp` (`tbl_exp_id`, `exp_type`, `remark`, `cap_type`, `amount`, `date`, `tbl_exp_timestamp`) VALUES ('6', 'To Investor', 'Kenny Took 20K', '2', '20000', '2019-12-06', '2019-12-30 21:25:16');
INSERT INTO `tbl_exp` (`tbl_exp_id`, `exp_type`, `remark`, `cap_type`, `amount`, `date`, `tbl_exp_timestamp`) VALUES ('7', 'Others', 'Account closed early, discounted 1000 INR- RADHIKA', '2', '1000', '2020-01-28', '2020-01-29 22:40:53');
INSERT INTO `tbl_exp` (`tbl_exp_id`, `exp_type`, `remark`, `cap_type`, `amount`, `date`, `tbl_exp_timestamp`) VALUES ('8', 'To Investor', 'To Kenny From Asha', '2', '40000', '2020-02-10', '2020-02-12 11:21:23');
INSERT INTO `tbl_exp` (`tbl_exp_id`, `exp_type`, `remark`, `cap_type`, `amount`, `date`, `tbl_exp_timestamp`) VALUES ('12', 'Discounts ', 'Lingo early finish ', '2', '5000', '2020-03-06', '2020-03-07 00:33:38');


#
# TABLE STRUCTURE FOR: tbl_exp_type
#

DROP TABLE IF EXISTS `tbl_exp_type`;

CREATE TABLE `tbl_exp_type` (
  `id` int(250) NOT NULL AUTO_INCREMENT,
  `exp_type` varchar(250) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_exp_type` (`id`, `exp_type`, `timestamp`) VALUES ('1', 'Stationary', '2019-12-17 19:38:27');
INSERT INTO `tbl_exp_type` (`id`, `exp_type`, `timestamp`) VALUES ('2', 'Salary', '2019-12-17 19:38:50');
INSERT INTO `tbl_exp_type` (`id`, `exp_type`, `timestamp`) VALUES ('3', 'Transport', '2019-12-17 19:39:06');
INSERT INTO `tbl_exp_type` (`id`, `exp_type`, `timestamp`) VALUES ('4', 'Internet/Phone Bill', '2019-12-17 19:39:25');
INSERT INTO `tbl_exp_type` (`id`, `exp_type`, `timestamp`) VALUES ('5', 'Others', '2019-12-17 19:39:37');
INSERT INTO `tbl_exp_type` (`id`, `exp_type`, `timestamp`) VALUES ('7', 'To Investor', '2019-12-30 21:22:15');
INSERT INTO `tbl_exp_type` (`id`, `exp_type`, `timestamp`) VALUES ('8', 'Discounts ', '2020-03-07 00:32:51');


#
# TABLE STRUCTURE FOR: tbl_image
#

DROP TABLE IF EXISTS `tbl_image`;

CREATE TABLE `tbl_image` (
  `imgid` int(255) NOT NULL AUTO_INCREMENT,
  `cust_img_path` varchar(255) NOT NULL,
  `id` int(255) NOT NULL,
  PRIMARY KEY (`imgid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('1', '20190912155220.jpeg', '50');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('2', '20190912155310.jpeg', '49');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('3', '20190912155410.jpeg', '48');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('4', '20190912155436.jpeg', '48');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('5', '20190913233819.jpeg', '54');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('6', '20190913233902.jpeg', '52');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('7', '20191031163234.jpeg', '58');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('8', '20191202131548.jpeg', '62');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('9', 'CEDF650A-CC23-42DA-982F-00BBB7C26483.jpeg', '64');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('10', 'CEDF650A-CC23-42DA-982F-00BBB7C264831.jpeg', '65');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('11', '20191220161705.jpeg', '70');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('12', '20191220161717.jpeg', '70');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('13', '20191220161946.png', '61');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('14', '20191220162013.png', '59');
INSERT INTO `tbl_image` (`imgid`, `cust_img_path`, `id`) VALUES ('15', '20191220162043.png', '56');


#
# TABLE STRUCTURE FOR: tbl_loan
#

DROP TABLE IF EXISTS `tbl_loan`;

CREATE TABLE `tbl_loan` (
  `loan_id` int(255) NOT NULL AUTO_INCREMENT,
  `id` int(255) DEFAULT NULL,
  `loanamt` varchar(255) DEFAULT NULL,
  `lenderamt` int(255) DEFAULT NULL,
  `loandate` varchar(255) DEFAULT NULL,
  `is_approve` int(255) NOT NULL DEFAULT '0',
  `is_active` int(5) NOT NULL DEFAULT '0',
  `loan_Type` int(250) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`loan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('1', '48', '50000', '60000', '09/04/2019', '1', '1', '1', '2019-09-04 19:23:24');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('2', '49', '20000', '24000', '09/05/2019', '1', '1', '1', '2019-09-05 17:01:57');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('3', '50', '20000', '24000', '09/10/2019', '1', '1', '1', '2019-09-10 20:39:08');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('4', '52', '20000', '24000', '09/12/2019', '1', '1', '1', '2019-09-12 20:48:49');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('5', '53', '20000', '24000', '09/12/2019', '1', '1', '1', '2019-09-12 20:52:13');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('6', '54', '30000', '36000', '09/13/2019', '1', '1', '1', '2019-09-13 11:16:36');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('7', '47', '30000', '36000', '09/19/2019', '1', '1', '2', '2019-09-19 16:02:31');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('8', '55', '50000', '60000', '10/01/2019', '1', '1', '3', '2019-10-01 23:50:31');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('9', '49', '10000', '12000', '10/14/2019', '1', '0', '2', '2019-10-14 19:34:17');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('10', '56', '20000', '24000', '10/17/2019', '1', '1', '2', '2019-10-18 12:26:18');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('11', '57', '20000', '24000', '10/24/2019', '1', '1', '2', '2019-10-24 17:46:24');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('12', '58', '20000', '24000', '10/31/2019', '1', '1', '2', '2019-10-31 21:58:19');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('13', '59', '10000', '12000', '11/11/2019', '1', '1', '2', '2019-11-11 23:26:29');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('14', '60', '30000', '36000', '11/15/2019', '1', '1', '2', '2019-11-15 20:24:09');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('15', '61', '30000', '36000', '11/28/2019', '1', '0', '2', '2019-11-28 18:58:41');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('16', '62', '10000', '12000', '12/02/2019', '1', '0', '2', '2019-12-02 18:03:15');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('17', '58', '50000', '60000', '12/06/2019', '1', '0', '2', '2019-12-05 21:54:51');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('19', '65', '10000', '12000', '12/11/2019', '1', '0', '2', '2019-12-09 22:14:28');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('20', '70', '20000', '24000', '12/19/2019', '1', '0', '2', '2019-12-20 21:39:45');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('21', '48', '100000', '120000', '12/28/2019', '1', '0', '3', '2019-12-27 19:28:18');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('22', '54', '50000', '60000', '01/09/2020', '1', '1', '2', '2020-01-08 22:55:18');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('23', '53', '10000', '12000', '01/14/2020', '1', '1', '2', '2020-01-14 21:00:44');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('24', '47', '30000', '36000', '01/20/2020', '1', '0', '2', '2020-01-20 21:51:29');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('25', '71', '50000', '60000', '02/05/2020', '1', '0', '2', '2020-02-05 20:02:24');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('26', '57', '20000', '24000', '02/17/2020', '1', '0', '2', '2020-02-16 19:01:10');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('27', '60', '30000', '36000', '02/23/2020', '1', '0', '2', '2020-02-25 20:35:03');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('28', '65', '10000', '12000', '03/05/2020', '1', '0', '2', '2020-03-05 22:09:17');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('29', '54', '100000', '120000', '03/08/2020', '1', '0', '3', '2020-03-09 00:30:13');
INSERT INTO `tbl_loan` (`loan_id`, `id`, `loanamt`, `lenderamt`, `loandate`, `is_approve`, `is_active`, `loan_Type`, `created_on`) VALUES ('30', '53', '10000', '12000', '03/10/2020', '1', '0', '2', '2020-03-10 04:50:08');


#
# TABLE STRUCTURE FOR: tbl_loan_type_amt
#

DROP TABLE IF EXISTS `tbl_loan_type_amt`;

CREATE TABLE `tbl_loan_type_amt` (
  `tbl_loan_type_amt_id` int(255) NOT NULL AUTO_INCREMENT,
  `loan_id` varchar(255) DEFAULT NULL,
  `loan_Type` varchar(255) DEFAULT NULL,
  `capital_amt` varchar(255) DEFAULT NULL,
  `reinvest_amt` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tbl_loan_type_amt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('1', '1', '1', '50000', '0', '2019-09-25 15:18:54');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('2', '2', '1', '20000', '0', '2019-09-25 15:18:54');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('3', '3', '1', '20000', '0', '2019-09-25 15:18:54');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('4', '4', '1', '20000', '0', '2019-09-25 15:18:54');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('5', '5', '1', '20000', '0', '2019-09-25 15:18:54');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('6', '6', '3', '20000', '10000', '2019-09-25 15:18:54');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('7', '7', '2', '30000', '0', '2019-09-25 15:18:54');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('9', '8', '3', '20000', '30000', '2019-10-01 23:51:02');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('11', '9', '2', '0', '10000', '2019-10-15 21:24:29');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('12', '10', '2', '0', '20000', '2019-10-18 12:26:34');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('13', '11', '2', '0', '20000', '2019-10-24 17:46:36');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('14', '12', '2', '0', '20000', '2019-10-31 21:58:36');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('15', '13', '2', '0', '10000', '2019-11-11 23:26:50');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('16', '14', '2', '0', '30000', '2019-11-15 20:24:24');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('17', '15', '2', '0', '30000', '2019-11-28 18:58:58');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('18', '16', '2', '0', '10000', '2019-12-02 18:03:34');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('19', '17', '2', '0', '50000', '2019-12-05 21:57:24');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('23', '19', '2', '0', '10000', '2019-12-10 14:47:01');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('26', '20', '2', '0', '20000', '2019-12-20 21:40:05');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('27', '21', '3', '50000', '50000', '2019-12-27 19:29:14');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('28', '22', '2', '0', '50000', '2020-01-08 22:55:35');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('29', '23', '2', '0', '10000', '2020-01-14 21:01:03');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('30', '24', '2', '0', '30000', '2020-01-20 21:51:42');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('31', '25', '2', '0', '50000', '2020-02-05 20:02:45');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('32', '26', '2', '0', '20000', '2020-02-16 19:01:28');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('33', '27', '2', '0', '30000', '2020-02-25 20:35:25');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('34', '28', '2', '0', '10000', '2020-03-05 22:09:33');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('35', '29', '3', '50000', '50000', '2020-03-09 00:31:22');
INSERT INTO `tbl_loan_type_amt` (`tbl_loan_type_amt_id`, `loan_id`, `loan_Type`, `capital_amt`, `reinvest_amt`, `created_on`) VALUES ('36', '30', '2', '0', '10000', '2020-03-10 04:50:23');


#
# TABLE STRUCTURE FOR: tbl_masterloanreport
#

DROP TABLE IF EXISTS `tbl_masterloanreport`;

CREATE TABLE `tbl_masterloanreport` (
  `tbl_masterloanreport_id` int(250) NOT NULL AUTO_INCREMENT,
  `date` varchar(250) DEFAULT NULL,
  `custone_id` int(250) DEFAULT NULL,
  `customer_name` varchar(250) DEFAULT NULL,
  `loan_id` varchar(50) DEFAULT NULL,
  `loan_amount` varchar(50) DEFAULT NULL,
  `assign_collector` varchar(100) DEFAULT NULL,
  `loan_Type` varchar(50) DEFAULT NULL,
  `interest` varchar(50) DEFAULT NULL,
  `collected_amount` varchar(50) DEFAULT NULL,
  `remaining_amount` varchar(50) DEFAULT NULL,
  `tbl_masterloanreport_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tbl_masterloanreport_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('1', '09/04/2019', '48', 'Jainath Prasad', '1', '50000', '43', '1', '10000', '60000', '0', '2019-09-12 18:55:44');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('2', '09/05/2019', '49', 'Hibu Yassung', '2', '20000', '43', '1', '4000', '24000', '0', '2019-09-12 19:48:31');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('3', '09/10/2019', '50', 'Madhav Sinha Munna', '3', '20000', '43', '1', '4000', '24000', '0', '2019-09-12 19:48:31');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('4', '09/12/2019', '52', 'Krishna  Chetry', '4', '20000', '43', '1', '4000', '24000', '0', '2019-09-12 20:48:49');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('5', '09/12/2019', '53', 'Radhika Kala Baido', '5', '20000', '43', '1', '4000', '24000', '0', '2019-09-12 20:52:14');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('6', '09/13/2019', '54', 'Ige  Lingo', '6', '30000', '43', '1', '6000', '36000', '0', '2019-09-13 11:16:36');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('7', '09/19/2019', '47', 'Jugi Yajen ', '7', '30000', '43', '2', '6000', '36000', '0', '2019-09-19 16:02:31');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('8', '10/01/2019', '55', 'Bibhuchandra  Singah', '8', '50000', '43', '3', '10000', '60000', '0', '2019-10-01 23:50:32');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('9', '10/14/2019', '49', 'Hibu Yassung', '9', '10000', '43', '2', '2000', '12000', '0', '2019-10-14 19:34:17');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('10', '10/17/2019', '56', 'Shanti  Dorjee', '10', '20000', '43', '2', '4000', '24000', '0', '2019-10-18 12:26:18');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('11', '10/24/2019', '57', 'Tadu  Rillung', '11', '20000', '43', '2', '4000', '24000', '0', '2019-10-24 17:46:24');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('12', '10/31/2019', '58', 'Gopar Riba', '12', '20000', '43', '2', '4000', '24000', '0', '2019-10-31 21:58:19');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('13', '11/11/2019', '59', 'BALIKA m', '13', '10000', '43', '2', '2000', '12000', '0', '2019-11-11 23:26:29');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('14', '11/15/2019', '60', 'Chandra  Bahadur', '14', '30000', '43', '2', '6000', '36000', '0', '2019-11-15 20:24:09');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('15', '11/28/2019', '61', 'Nani  Oniya', '15', '30000', '43', '2', '6000', '31400', '4600', '2019-11-28 18:58:41');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('16', '12/02/2019', '62', 'Avi Roto', '16', '10000', '43', '2', '2000', '5000', '7000', '2019-12-02 18:03:15');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('17', '12/06/2019', '58', '   Goper    Riba', '17', '50000', '43', '2', '10000', '49500', '10500', '2019-12-05 21:54:51');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('19', '8/11/2019', '65', 'Likha Yapi', '19', '10000', '43', '2', '2000', '10000', '2000', '2019-12-09 22:14:28');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('20', '12/19/2019', '70', 'Sanu Limbu', '20', '20000', '43', '2', '4000', '16000', '8000', '2019-12-20 21:39:45');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('21', '12/28/2019', '48', ' Jainath  Prasad', '21', '100000', '43', '3', '20000', '16000', '104000', '2019-12-27 19:28:18');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('22', '01/09/2020', '54', 'Ige  Lingo', '22', '50000', '43', '2', '10000', '60000', '0', '2020-01-08 22:55:18');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('23', '01/14/2020', '53', 'Radhika Kala Baido', '23', '10000', '43', '2', '2000', '12000', '0', '2020-01-14 21:00:44');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('24', '01/20/2020', '47', ' Jugi  Yajen ', '24', '30000', '43', '2', '6000', '16200', '19800', '2020-01-20 21:51:29');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('25', '02/05/2020', '71', 'Noor Ali', '25', '50000', '43', '2', '10000', '39000', '21000', '2020-02-05 20:02:24');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('26', '02/17/2020', '57', 'Tadu  Rillung', '26', '20000', '43', '2', '4000', '3800', '20200', '2020-02-16 19:01:10');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('27', '02/23/2020', '60', 'Chandra  Bahadur', '27', '30000', '43', '2', '6000', '6300', '29700', '2020-02-25 20:35:03');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('28', '03/05/2020', '65', 'Likha Yapi', '28', '10000', '43', '2', '2000', '1000', '11000', '2020-03-05 22:09:17');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('29', '03/08/2020', '54', 'Ige  Lingo', '29', '100000', '43', '3', '20000', '7000', '113000', '2020-03-09 00:30:13');
INSERT INTO `tbl_masterloanreport` (`tbl_masterloanreport_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `assign_collector`, `loan_Type`, `interest`, `collected_amount`, `remaining_amount`, `tbl_masterloanreport_timestamp`) VALUES ('30', '03/10/2020', '53', 'Radhika Kala Baido', '30', '10000', '43', '2', '2000', '500', '11500', '2020-03-10 04:50:08');


#
# TABLE STRUCTURE FOR: tbl_pay
#

DROP TABLE IF EXISTS `tbl_pay`;

CREATE TABLE `tbl_pay` (
  `pay_id` int(5) NOT NULL AUTO_INCREMENT,
  `loan_id` int(255) NOT NULL,
  `collector_id` int(255) NOT NULL,
  `loanamt` int(255) NOT NULL,
  `pay_loan_amt` int(255) NOT NULL,
  `loandate` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1566 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1', '1', '43', '50000', '500', '2019-09-05', '2019-09-05 16:53:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('2', '2', '43', '20000', '200', '2019-09-06', '2019-09-06 20:14:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('3', '1', '43', '50000', '500', '2019-09-06', '2019-09-06 20:15:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('4', '1', '43', '50000', '500', '2019-09-07', '2019-09-07 19:37:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('5', '2', '43', '20000', '200', '2019-09-07', '2019-09-07 19:38:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('6', '1', '43', '50000', '500', '2019-09-08', '2019-09-08 14:56:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('7', '2', '43', '20000', '200', '2019-09-08', '2019-09-08 14:57:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('8', '1', '43', '50000', '500', '2019-09-09', '2019-09-09 16:06:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('9', '2', '43', '20000', '200', '2019-09-09', '2019-09-09 19:07:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('10', '1', '43', '50000', '500', '2019-09-10', '2019-09-10 19:38:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('11', '2', '43', '20000', '200', '2019-09-10', '2019-09-10 19:38:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('12', '1', '43', '50000', '500', '2019-09-11', '2019-09-11 16:42:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('13', '2', '43', '20000', '200', '2019-09-11', '2019-09-11 16:42:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('14', '3', '43', '20000', '200', '2019-09-11', '2019-09-11 16:43:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('15', '1', '43', '50000', '500', '2019-09-12', '2019-09-12 20:44:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('16', '2', '43', '20000', '200', '2019-09-12', '2019-09-12 20:44:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('17', '3', '43', '20000', '200', '2019-09-12', '2019-09-12 20:44:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('18', '4', '43', '20000', '200', '2019-09-12', '2019-09-12 20:49:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('19', '5', '43', '20000', '200', '2019-09-12', '2019-09-12 20:52:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('20', '6', '43', '30000', '300', '2019-09-13', '2019-09-13 11:17:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('21', '1', '43', '50000', '500', '2019-09-13', '2019-09-13 17:48:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('22', '2', '43', '20000', '200', '2019-09-13', '2019-09-13 17:49:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('23', '3', '43', '20000', '200', '2019-09-13', '2019-09-13 17:49:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('24', '4', '43', '20000', '200', '2019-09-13', '2019-09-13 17:49:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('25', '5', '43', '20000', '200', '2019-09-13', '2019-09-13 17:49:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('26', '1', '43', '50000', '1500', '2019-09-16', '2019-09-16 19:21:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('27', '2', '43', '20000', '600', '2019-09-16', '2019-09-16 19:21:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('28', '3', '43', '20000', '600', '2019-09-16', '2019-09-16 19:21:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('29', '4', '43', '20000', '600', '2019-09-16', '2019-09-16 19:22:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('31', '6', '43', '30000', '900', '2019-09-16', '2019-09-16 19:22:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('32', '1', '43', '50000', '500', '2019-09-17', '2019-09-17 18:17:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('33', '2', '43', '20000', '200', '2019-09-17', '2019-09-17 18:17:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('34', '4', '43', '20000', '200', '2019-09-17', '2019-09-17 18:18:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('35', '5', '43', '20000', '200', '2019-09-17', '2019-09-17 18:18:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('36', '6', '43', '30000', '300', '2019-09-17', '2019-09-17 18:19:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('37', '1', '43', '50000', '500', '2019-09-18', '2019-09-18 20:09:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('38', '2', '43', '20000', '200', '2019-09-18', '2019-09-18 20:09:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('39', '5', '43', '20000', '200', '2019-09-18', '2019-09-18 20:10:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('41', '6', '43', '30000', '300', '2019-09-18', '2019-09-18 20:10:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('42', '1', '43', '50000', '500', '2019-09-19', '2019-09-19 19:24:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('43', '2', '43', '20000', '200', '2019-09-19', '2019-09-19 19:24:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('44', '4', '43', '20000', '200', '2019-09-19', '2019-09-19 19:24:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('45', '6', '43', '30000', '300', '2019-09-19', '2019-09-19 19:25:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('46', '1', '43', '50000', '500', '2019-09-20', '2019-09-20 19:04:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('47', '2', '43', '20000', '200', '2019-09-20', '2019-09-20 19:04:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('48', '4', '43', '20000', '200', '2019-09-20', '2019-09-20 19:05:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('49', '5', '43', '20000', '200', '2019-09-20', '2019-09-20 19:05:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('50', '6', '43', '30000', '300', '2019-09-20', '2019-09-20 19:05:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('51', '7', '43', '30000', '300', '2019-09-20', '2019-09-20 19:05:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('52', '4', '43', '20000', '200', '2019-09-20', '2019-09-20 19:08:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('53', '5', '43', '20000', '200', '2019-09-20', '2019-09-20 19:13:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('54', '1', '43', '50000', '500', '2019-09-21', '2019-09-21 18:19:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('55', '2', '43', '20000', '200', '2019-09-21', '2019-09-21 18:19:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('56', '3', '43', '20000', '200', '2019-09-21', '2019-09-21 18:19:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('57', '3', '43', '20000', '200', '2019-09-21', '2019-09-21 18:19:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('58', '4', '43', '20000', '200', '2019-09-21', '2019-09-21 18:19:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('59', '5', '43', '20000', '200', '2019-09-21', '2019-09-21 18:20:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('60', '6', '43', '30000', '300', '2019-09-21', '2019-09-21 18:20:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('61', '7', '43', '30000', '300', '2019-09-21', '2019-09-21 18:20:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('62', '1', '43', '50000', '500', '2019-09-22', '2019-09-22 21:25:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('63', '2', '43', '20000', '200', '2019-09-22', '2019-09-22 21:26:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('64', '5', '43', '20000', '200', '2019-09-22', '2019-09-22 21:26:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('65', '5', '43', '20000', '200', '2019-09-22', '2019-09-22 21:26:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('66', '7', '43', '30000', '300', '2019-09-22', '2019-09-22 21:26:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('67', '6', '43', '30000', '300', '2019-09-22', '2019-09-22 21:27:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('68', '1', '43', '50000', '500', '2019-09-23', '2019-09-23 19:17:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('69', '2', '43', '20000', '200', '2019-09-23', '2019-09-23 19:17:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('70', '3', '43', '20000', '200', '2019-09-23', '2019-09-23 19:18:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('71', '4', '43', '20000', '200', '2019-09-23', '2019-09-23 19:19:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('72', '6', '43', '30000', '300', '2019-09-23', '2019-09-23 19:19:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('73', '7', '43', '30000', '300', '2019-09-23', '2019-09-23 19:20:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('74', '1', '43', '50000', '500', '2019-09-24', '2019-09-24 19:40:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('75', '2', '43', '20000', '200', '2019-09-24', '2019-09-24 19:40:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('76', '3', '43', '20000', '200', '2019-09-24', '2019-09-24 19:40:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('77', '4', '43', '20000', '200', '2019-09-24', '2019-09-24 19:40:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('78', '5', '43', '20000', '200', '2019-09-24', '2019-09-24 19:40:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('79', '6', '43', '30000', '300', '2019-09-24', '2019-09-24 19:40:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('80', '7', '43', '30000', '300', '2019-09-24', '2019-09-24 19:41:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('81', '1', '43', '50000', '500', '2019-09-25', '2019-09-25 20:36:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('82', '2', '43', '20000', '200', '2019-09-25', '2019-09-25 20:36:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('83', '3', '43', '20000', '200', '2019-09-25', '2019-09-25 20:37:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('84', '4', '43', '20000', '200', '2019-09-25', '2019-09-25 20:37:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('85', '5', '43', '20000', '200', '2019-09-25', '2019-09-25 20:37:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('86', '6', '43', '30000', '300', '2019-09-25', '2019-09-25 20:37:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('87', '7', '43', '30000', '300', '2019-09-25', '2019-09-25 20:37:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('88', '1', '43', '50000', '500', '2019-09-26', '2019-09-26 19:09:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('89', '2', '43', '20000', '200', '2019-09-26', '2019-09-26 19:09:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('90', '3', '43', '20000', '200', '2019-09-26', '2019-09-26 19:09:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('91', '4', '43', '20000', '200', '2019-09-26', '2019-09-26 19:10:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('92', '5', '43', '20000', '200', '2019-09-26', '2019-09-26 19:10:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('93', '6', '43', '30000', '300', '2019-09-26', '2019-09-26 19:11:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('94', '7', '43', '30000', '300', '2019-09-26', '2019-09-26 19:11:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('96', '1', '43', '50000', '500', '2019-09-27', '2019-09-27 20:54:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('97', '2', '43', '20000', '200', '2019-09-27', '2019-09-27 20:54:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('98', '3', '43', '20000', '200', '2019-09-27', '2019-09-27 20:54:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('99', '4', '43', '20000', '200', '2019-09-27', '2019-09-27 20:54:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('100', '5', '43', '20000', '200', '2019-09-27', '2019-09-27 20:55:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('101', '6', '43', '30000', '300', '2019-09-27', '2019-09-27 20:55:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('102', '7', '43', '30000', '300', '2019-09-27', '2019-09-27 20:55:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('103', '1', '43', '50000', '500', '2019-09-28', '2019-09-28 21:33:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('104', '2', '43', '20000', '200', '2019-09-28', '2019-09-28 21:33:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('105', '3', '43', '20000', '200', '2019-09-28', '2019-09-28 21:33:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('106', '4', '43', '20000', '200', '2019-09-28', '2019-09-28 21:33:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('107', '5', '43', '20000', '200', '2019-09-28', '2019-09-28 21:33:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('108', '6', '43', '30000', '300', '2019-09-28', '2019-09-28 21:33:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('109', '7', '43', '30000', '300', '2019-09-28', '2019-09-28 21:33:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('111', '1', '43', '50000', '500', '2019-09-29', '2019-09-29 22:59:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('113', '3', '43', '20000', '200', '2019-09-29', '2019-09-29 23:00:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('114', '4', '43', '20000', '200', '2019-09-29', '2019-09-29 23:00:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('115', '5', '43', '20000', '200', '2019-09-29', '2019-09-29 23:01:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('116', '6', '43', '30000', '300', '2019-09-29', '2019-09-29 23:01:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('117', '7', '43', '30000', '300', '2019-09-29', '2019-09-29 23:01:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('119', '2', '43', '20000', '200', '2019-09-30', '2019-09-30 18:23:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('120', '3', '43', '20000', '200', '2019-09-30', '2019-09-30 18:23:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('121', '4', '43', '20000', '200', '2019-09-30', '2019-09-30 18:23:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('122', '5', '43', '20000', '200', '2019-09-30', '2019-09-30 18:23:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('123', '6', '43', '30000', '300', '2019-09-30', '2019-09-30 18:23:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('124', '7', '43', '30000', '300', '2019-09-30', '2019-09-30 18:23:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('125', '2', '43', '20000', '200', '2019-10-01', '2019-10-01 23:43:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('126', '3', '43', '20000', '200', '2019-10-01', '2019-10-01 23:43:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('127', '4', '43', '20000', '200', '2019-10-01', '2019-10-01 23:43:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('128', '5', '43', '20000', '200', '2019-10-01', '2019-10-01 23:43:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('129', '6', '43', '30000', '300', '2019-10-01', '2019-10-01 23:43:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('130', '7', '43', '30000', '300', '2019-10-01', '2019-10-01 23:43:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('131', '1', '43', '50000', '500', '2019-10-02', '2019-10-04 15:43:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('132', '2', '43', '20000', '200', '2019-10-02', '2019-10-04 15:43:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('133', '3', '43', '20000', '200', '2019-10-02', '2019-10-04 15:43:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('134', '4', '43', '20000', '200', '2019-10-02', '2019-10-04 15:43:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('135', '5', '43', '20000', '200', '2019-10-02', '2019-10-04 15:43:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('136', '6', '43', '30000', '300', '2019-10-02', '2019-10-04 15:44:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('137', '7', '43', '30000', '300', '2019-10-02', '2019-10-04 15:44:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('138', '8', '43', '50000', '500', '2019-10-02', '2019-10-04 15:44:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('139', '2', '43', '20000', '200', '2019-10-03', '2019-10-04 15:45:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('140', '3', '43', '20000', '200', '2019-10-03', '2019-10-04 15:45:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('141', '4', '43', '20000', '200', '2019-10-03', '2019-10-04 15:45:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('142', '5', '43', '20000', '200', '2019-10-03', '2019-10-04 15:46:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('143', '6', '43', '30000', '300', '2019-10-03', '2019-10-04 15:46:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('144', '7', '43', '30000', '300', '2019-10-03', '2019-10-04 15:46:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('145', '8', '43', '50000', '500', '2019-10-03', '2019-10-04 15:46:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('146', '1', '43', '50000', '1000', '2019-10-04', '2019-10-04 20:50:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('147', '2', '43', '20000', '200', '2019-10-04', '2019-10-04 20:50:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('148', '3', '43', '20000', '200', '2019-10-04', '2019-10-04 20:50:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('149', '4', '43', '20000', '200', '2019-10-04', '2019-10-04 20:50:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('150', '5', '43', '20000', '200', '2019-10-04', '2019-10-04 20:50:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('151', '6', '43', '30000', '300', '2019-10-04', '2019-10-04 20:53:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('152', '7', '43', '30000', '300', '2019-10-04', '2019-10-04 20:53:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('153', '8', '43', '50000', '500', '2019-10-04', '2019-10-04 20:53:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('154', '1', '43', '50000', '500', '2019-10-05', '2019-10-05 20:20:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('155', '2', '43', '20000', '200', '2019-10-05', '2019-10-05 20:20:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('156', '3', '43', '20000', '200', '2019-10-05', '2019-10-05 20:20:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('157', '4', '43', '20000', '200', '2019-10-05', '2019-10-05 20:20:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('158', '5', '43', '20000', '200', '2019-10-05', '2019-10-05 20:20:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('159', '6', '43', '30000', '300', '2019-10-05', '2019-10-05 20:20:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('160', '7', '43', '30000', '300', '2019-10-05', '2019-10-05 20:21:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('161', '8', '43', '50000', '500', '2019-10-05', '2019-10-05 20:21:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('162', '1', '43', '50000', '1000', '2019-10-07', '2019-10-07 19:07:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('163', '2', '43', '20000', '400', '2019-10-07', '2019-10-07 19:08:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('164', '4', '43', '20000', '400', '2019-10-07', '2019-10-07 19:08:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('165', '5', '43', '20000', '200', '2019-10-07', '2019-10-07 19:08:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('166', '6', '43', '30000', '600', '2019-10-07', '2019-10-07 19:08:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('167', '7', '43', '30000', '600', '2019-10-07', '2019-10-07 19:08:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('168', '1', '43', '50000', '500', '2019-10-08', '2019-10-08 19:03:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('169', '2', '43', '20000', '200', '2019-10-08', '2019-10-08 19:04:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('170', '5', '43', '20000', '200', '2019-10-08', '2019-10-08 19:04:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('171', '6', '43', '30000', '300', '2019-10-08', '2019-10-08 19:04:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('172', '7', '43', '30000', '300', '2019-10-08', '2019-10-08 19:04:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('173', '1', '43', '50000', '500', '2019-10-09', '2019-10-09 20:12:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('174', '4', '43', '20000', '400', '2019-10-09', '2019-10-09 20:12:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('175', '2', '43', '20000', '200', '2019-10-09', '2019-10-09 20:13:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('176', '3', '43', '20000', '400', '2019-10-09', '2019-10-09 20:13:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('177', '7', '43', '30000', '300', '2019-10-09', '2019-10-09 20:13:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('178', '6', '43', '30000', '300', '2019-10-09', '2019-10-09 20:13:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('179', '5', '43', '20000', '200', '2019-10-09', '2019-10-09 20:13:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('180', '8', '43', '50000', '1000', '2019-10-09', '2019-10-09 20:14:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('181', '8', '43', '50000', '1000', '2019-10-10', '2019-10-10 19:32:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('182', '1', '43', '50000', '500', '2019-10-10', '2019-10-10 19:32:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('183', '2', '43', '20000', '200', '2019-10-10', '2019-10-10 19:32:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('184', '3', '43', '20000', '400', '2019-10-10', '2019-10-10 19:32:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('185', '6', '43', '30000', '300', '2019-10-10', '2019-10-10 19:32:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('186', '5', '43', '20000', '200', '2019-10-10', '2019-10-10 19:32:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('187', '7', '43', '30000', '300', '2019-10-10', '2019-10-10 19:33:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('188', '4', '43', '20000', '200', '2019-10-10', '2019-10-10 19:33:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('189', '3', '43', '20000', '400', '2019-10-11', '2019-10-11 19:18:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('190', '8', '43', '50000', '1000', '2019-10-11', '2019-10-11 19:19:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('191', '1', '43', '50000', '500', '2019-10-11', '2019-10-11 19:19:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('192', '2', '43', '20000', '200', '2019-10-11', '2019-10-11 19:19:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('193', '4', '43', '20000', '200', '2019-10-11', '2019-10-11 19:19:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('194', '7', '43', '30000', '300', '2019-10-11', '2019-10-11 19:19:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('195', '5', '43', '20000', '200', '2019-10-11', '2019-10-11 19:19:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('196', '6', '43', '30000', '300', '2019-10-11', '2019-10-11 19:19:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('197', '1', '43', '50000', '500', '2019-10-12', '2019-10-12 19:07:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('198', '2', '43', '20000', '200', '2019-10-12', '2019-10-12 19:08:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('199', '3', '43', '20000', '200', '2019-10-12', '2019-10-12 19:08:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('200', '5', '43', '20000', '200', '2019-10-12', '2019-10-12 19:08:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('201', '6', '43', '30000', '300', '2019-10-12', '2019-10-12 19:09:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('202', '7', '43', '30000', '300', '2019-10-12', '2019-10-12 19:09:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('203', '8', '43', '50000', '500', '2019-10-12', '2019-10-12 19:09:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('204', '1', '43', '50000', '500', '2019-10-13', '2019-10-13 18:58:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('205', '2', '43', '20000', '200', '2019-10-13', '2019-10-13 19:13:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('206', '5', '43', '20000', '200', '2019-10-13', '2019-10-13 19:13:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('207', '6', '43', '30000', '300', '2019-10-13', '2019-10-13 19:13:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('208', '7', '43', '30000', '300', '2019-10-13', '2019-10-13 19:13:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('209', '1', '43', '50000', '500', '2019-10-14', '2019-10-14 19:19:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('210', '2', '43', '20000', '200', '2019-10-14', '2019-10-14 19:31:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('211', '8', '43', '50000', '1000', '2019-10-14', '2019-10-14 19:31:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('212', '6', '43', '30000', '300', '2019-10-14', '2019-10-14 19:32:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('213', '7', '43', '30000', '300', '2019-10-14', '2019-10-14 19:32:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('214', '5', '43', '20000', '200', '2019-10-14', '2019-10-14 19:32:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('215', '3', '43', '20000', '400', '2019-10-14', '2019-10-14 19:32:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('216', '8', '43', '50000', '500', '2019-10-15', '2019-10-15 20:10:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('217', '1', '43', '50000', '500', '2019-10-16', '2019-10-16 20:57:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('218', '2', '43', '20000', '200', '2019-10-16', '2019-10-16 20:57:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('219', '8', '43', '50000', '500', '2019-10-16', '2019-10-16 20:57:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('220', '9', '43', '10000', '100', '2019-10-16', '2019-10-16 20:57:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('221', '6', '43', '30000', '600', '2019-10-16', '2019-10-16 20:57:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('222', '7', '43', '30000', '300', '2019-10-16', '2019-10-16 20:58:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('223', '5', '43', '20000', '200', '2019-10-16', '2019-10-16 20:58:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('224', '3', '43', '20000', '200', '2019-10-16', '2019-10-16 20:58:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('225', '1', '43', '50000', '500', '2019-10-17', '2019-10-18 12:27:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('226', '2', '43', '20000', '200', '2019-10-17', '2019-10-18 12:27:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('227', '3', '43', '20000', '200', '2019-10-17', '2019-10-18 12:27:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('228', '5', '43', '20000', '200', '2019-10-17', '2019-10-18 12:27:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('229', '6', '43', '30000', '300', '2019-10-17', '2019-10-18 12:27:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('230', '7', '43', '30000', '300', '2019-10-17', '2019-10-18 12:28:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('231', '8', '43', '50000', '500', '2019-10-17', '2019-10-18 12:28:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('232', '9', '43', '10000', '100', '2019-10-17', '2019-10-18 12:28:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('233', '10', '43', '20000', '200', '2019-10-17', '2019-10-18 12:28:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('234', '1', '43', '50000', '500', '2019-10-18', '2019-10-18 18:31:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('235', '2', '43', '20000', '200', '2019-10-18', '2019-10-18 18:32:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('236', '3', '43', '20000', '200', '2019-10-18', '2019-10-18 18:32:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('237', '5', '43', '20000', '200', '2019-10-18', '2019-10-18 18:32:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('238', '6', '43', '30000', '300', '2019-10-18', '2019-10-18 18:32:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('239', '7', '43', '30000', '300', '2019-10-18', '2019-10-18 18:32:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('240', '8', '43', '50000', '500', '2019-10-18', '2019-10-18 18:32:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('241', '9', '43', '10000', '100', '2019-10-18', '2019-10-18 18:32:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('242', '10', '43', '20000', '200', '2019-10-18', '2019-10-18 18:32:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('243', '1', '43', '50000', '500', '2019-10-19', '2019-10-19 17:49:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('244', '2', '43', '20000', '200', '2019-10-19', '2019-10-19 17:49:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('245', '3', '43', '20000', '400', '2019-10-19', '2019-10-19 17:49:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('246', '5', '43', '20000', '200', '2019-10-19', '2019-10-19 17:49:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('247', '6', '43', '30000', '300', '2019-10-19', '2019-10-19 17:49:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('248', '7', '43', '30000', '300', '2019-10-19', '2019-10-19 17:49:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('249', '8', '43', '50000', '500', '2019-10-19', '2019-10-19 17:50:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('250', '9', '43', '10000', '100', '2019-10-19', '2019-10-19 17:50:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('251', '10', '43', '20000', '200', '2019-10-19', '2019-10-19 17:50:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('252', '8', '43', '50000', '500', '2019-10-20', '2019-10-21 09:38:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('253', '7', '43', '30000', '300', '2019-10-20', '2019-10-21 09:38:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('254', '6', '43', '30000', '300', '2019-10-20', '2019-10-21 09:38:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('255', '1', '43', '50000', '500', '2019-10-20', '2019-10-21 09:38:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('256', '10', '43', '20000', '200', '2019-10-20', '2019-10-21 09:38:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('257', '2', '43', '20000', '200', '2019-10-21', '2019-10-21 22:14:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('258', '9', '43', '10000', '200', '2019-10-21', '2019-10-21 22:14:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('259', '2', '43', '20000', '200', '2019-10-21', '2019-10-21 22:14:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('260', '1', '43', '50000', '500', '2019-10-21', '2019-10-21 22:14:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('261', '3', '43', '20000', '200', '2019-10-21', '2019-10-21 22:14:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('262', '8', '43', '50000', '500', '2019-10-21', '2019-10-21 22:14:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('263', '6', '43', '30000', '300', '2019-10-21', '2019-10-21 22:15:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('264', '7', '43', '30000', '300', '2019-10-21', '2019-10-21 22:15:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('265', '5', '43', '20000', '200', '2019-10-21', '2019-10-21 22:15:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('266', '8', '43', '50000', '500', '2019-10-22', '2019-10-22 19:16:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('267', '1', '43', '50000', '500', '2019-10-22', '2019-10-22 19:16:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('268', '2', '43', '20000', '200', '2019-10-22', '2019-10-22 19:16:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('269', '9', '43', '10000', '100', '2019-10-22', '2019-10-22 19:16:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('270', '7', '43', '30000', '300', '2019-10-22', '2019-10-22 19:16:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('271', '6', '43', '30000', '300', '2019-10-22', '2019-10-22 19:16:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('272', '5', '43', '20000', '200', '2019-10-22', '2019-10-22 19:16:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('273', '3', '43', '20000', '200', '2019-10-22', '2019-10-22 19:16:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('274', '10', '43', '20000', '400', '2019-10-22', '2019-10-22 19:17:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('275', '8', '43', '50000', '500', '2019-10-23', '2019-10-24 00:12:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('276', '1', '43', '50000', '500', '2019-10-23', '2019-10-24 00:13:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('277', '6', '43', '30000', '300', '2019-10-23', '2019-10-24 00:13:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('278', '7', '43', '30000', '300', '2019-10-23', '2019-10-24 00:13:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('279', '2', '43', '20000', '200', '2019-10-23', '2019-10-24 00:13:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('280', '9', '43', '10000', '100', '2019-10-23', '2019-10-24 00:13:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('281', '3', '43', '20000', '600', '2019-10-23', '2019-10-24 00:13:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('282', '10', '43', '20000', '200', '2019-10-23', '2019-10-24 00:13:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('283', '4', '43', '20000', '400', '2019-10-23', '2019-10-24 00:14:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('284', '1', '43', '50000', '500', '2019-10-24', '2019-10-24 17:52:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('285', '2', '43', '20000', '200', '2019-10-24', '2019-10-24 17:52:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('286', '3', '43', '20000', '200', '2019-10-24', '2019-10-24 17:53:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('287', '4', '43', '20000', '200', '2019-10-24', '2019-10-24 17:53:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('289', '5', '43', '20000', '200', '2019-10-24', '2019-10-24 17:53:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('290', '6', '43', '30000', '300', '2019-10-24', '2019-10-24 17:53:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('291', '7', '43', '30000', '300', '2019-10-24', '2019-10-24 17:53:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('292', '8', '43', '50000', '500', '2019-10-24', '2019-10-24 17:53:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('293', '9', '43', '10000', '100', '2019-10-24', '2019-10-24 17:53:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('294', '10', '43', '20000', '200', '2019-10-24', '2019-10-24 17:53:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('295', '1', '43', '50000', '500', '2019-10-25', '2019-10-26 07:35:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('296', '2', '43', '20000', '200', '2019-10-25', '2019-10-26 07:36:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('297', '3', '43', '20000', '200', '2019-10-25', '2019-10-26 07:36:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('298', '4', '43', '20000', '200', '2019-10-25', '2019-10-26 07:37:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('299', '5', '43', '20000', '200', '2019-10-25', '2019-10-26 07:37:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('300', '6', '43', '30000', '300', '2019-10-25', '2019-10-26 07:37:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('301', '7', '43', '30000', '300', '2019-10-25', '2019-10-26 07:37:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('302', '8', '43', '50000', '500', '2019-10-25', '2019-10-26 07:38:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('303', '9', '43', '10000', '100', '2019-10-25', '2019-10-26 07:38:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('304', '10', '43', '20000', '200', '2019-10-25', '2019-10-26 07:38:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('305', '11', '43', '20000', '200', '2019-10-25', '2019-10-26 07:38:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('306', '5', '43', '20000', '200', '2019-10-25', '2019-10-26 21:58:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('307', '1', '43', '50000', '500', '2019-10-26', '2019-10-26 21:59:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('308', '10', '43', '20000', '200', '2019-10-26', '2019-10-26 21:59:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('309', '8', '43', '50000', '500', '2019-10-26', '2019-10-26 22:00:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('310', '9', '43', '10000', '100', '2019-10-26', '2019-10-26 22:00:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('311', '2', '43', '20000', '200', '2019-10-26', '2019-10-26 22:00:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('312', '6', '43', '30000', '300', '2019-10-26', '2019-10-26 22:00:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('313', '7', '43', '30000', '300', '2019-10-26', '2019-10-26 22:00:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('314', '5', '43', '20000', '200', '2019-10-26', '2019-10-26 22:01:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('315', '3', '43', '20000', '400', '2019-10-26', '2019-10-26 22:01:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('316', '1', '43', '50000', '1000', '2019-10-28', '2019-10-28 19:32:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('317', '8', '43', '50000', '500', '2019-10-28', '2019-10-28 19:33:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('318', '8', '43', '50000', '500', '2019-10-27', '2019-10-28 19:33:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('319', '6', '43', '30000', '300', '2019-10-27', '2019-10-28 19:33:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('320', '6', '43', '30000', '300', '2019-10-28', '2019-10-28 19:33:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('321', '7', '43', '30000', '300', '2019-10-28', '2019-10-28 19:33:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('322', '7', '43', '30000', '300', '2019-10-27', '2019-10-28 19:34:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('323', '3', '43', '20000', '200', '2019-10-27', '2019-10-28 19:34:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('324', '3', '43', '20000', '200', '2019-10-28', '2019-10-28 19:34:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('325', '4', '43', '20000', '200', '2019-10-28', '2019-10-28 19:35:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('326', '4', '43', '20000', '400', '2019-10-27', '2019-10-28 19:35:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('327', '9', '43', '10000', '200', '2019-10-28', '2019-10-28 19:39:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('328', '2', '43', '20000', '400', '2019-10-28', '2019-10-28 19:39:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('329', '10', '43', '20000', '400', '2019-10-28', '2019-10-28 19:39:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('330', '11', '43', '20000', '400', '2019-10-28', '2019-10-28 19:39:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('331', '5', '43', '20000', '200', '2019-10-28', '2019-10-28 19:40:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('332', '2', '43', '20000', '200', '2019-10-29', '2019-10-30 00:33:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('333', '9', '43', '10000', '100', '2019-10-29', '2019-10-30 00:33:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('334', '3', '43', '20000', '200', '2019-10-29', '2019-10-30 00:33:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('335', '10', '43', '20000', '200', '2019-10-29', '2019-10-30 00:49:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('336', '4', '43', '20000', '200', '2019-10-29', '2019-10-30 00:49:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('337', '6', '43', '30000', '300', '2019-10-29', '2019-10-30 00:49:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('338', '7', '43', '30000', '300', '2019-10-29', '2019-10-30 00:49:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('339', '5', '43', '20000', '200', '2019-10-29', '2019-10-30 00:50:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('341', '11', '43', '20000', '200', '2019-10-29', '2019-10-30 00:51:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('342', '8', '43', '50000', '500', '2019-10-29', '2019-10-30 00:51:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('344', '10', '43', '20000', '200', '2019-10-30', '2019-10-30 23:54:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('345', '4', '43', '20000', '200', '2019-10-30', '2019-10-30 23:54:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('346', '3', '43', '20000', '200', '2019-10-30', '2019-10-30 23:54:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('347', '6', '43', '30000', '300', '2019-10-30', '2019-10-30 23:54:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('348', '7', '43', '30000', '300', '2019-10-30', '2019-10-30 23:54:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('349', '5', '43', '20000', '200', '2019-10-30', '2019-10-30 23:54:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('350', '2', '43', '20000', '200', '2019-10-30', '2019-10-30 23:55:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('351', '9', '43', '10000', '100', '2019-10-30', '2019-10-30 23:55:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('352', '8', '43', '50000', '500', '2019-10-30', '2019-10-30 23:55:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('353', '8', '43', '50000', '500', '2019-10-31', '2019-10-31 21:54:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('354', '9', '43', '10000', '100', '2019-10-31', '2019-10-31 21:54:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('355', '2', '43', '20000', '200', '2019-10-31', '2019-10-31 21:54:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('356', '6', '43', '30000', '300', '2019-10-31', '2019-10-31 21:55:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('357', '7', '43', '30000', '300', '2019-10-31', '2019-10-31 21:55:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('358', '11', '43', '20000', '200', '2019-10-31', '2019-10-31 21:55:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('359', '5', '43', '20000', '200', '2019-10-31', '2019-10-31 21:56:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('360', '10', '43', '20000', '200', '2019-10-31', '2019-10-31 21:56:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('361', '4', '43', '20000', '400', '2019-10-31', '2019-10-31 21:56:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('362', '10', '43', '20000', '200', '2019-10-31', '2019-10-31 21:56:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('363', '3', '43', '20000', '200', '2019-10-31', '2019-10-31 21:56:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('364', '4', '43', '20000', '400', '2019-11-01', '2019-11-02 20:16:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('365', '12', '43', '20000', '200', '2019-11-01', '2019-11-02 20:16:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('366', '6', '43', '30000', '300', '2019-11-01', '2019-11-02 20:16:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('367', '8', '43', '50000', '500', '2019-11-01', '2019-11-02 20:20:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('368', '2', '43', '20000', '200', '2019-11-01', '2019-11-02 20:21:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('370', '7', '43', '30000', '300', '2019-11-01', '2019-11-02 20:21:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('371', '5', '43', '20000', '200', '2019-11-01', '2019-11-02 20:22:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('373', '8', '43', '50000', '500', '2019-11-02', '2019-11-02 20:22:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('374', '6', '43', '30000', '300', '2019-11-02', '2019-11-02 20:22:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('375', '7', '43', '30000', '300', '2019-11-02', '2019-11-02 20:23:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('376', '5', '43', '20000', '200', '2019-11-02', '2019-11-02 20:23:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('377', '3', '43', '20000', '200', '2019-11-02', '2019-11-02 20:23:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('378', '4', '43', '20000', '200', '2019-11-02', '2019-11-02 20:23:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('379', '10', '43', '20000', '400', '2019-11-02', '2019-11-02 20:24:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('380', '12', '43', '20000', '200', '2019-11-02', '2019-11-02 20:24:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('382', '6', '43', '30000', '300', '2019-11-03', '2019-11-04 21:10:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('383', '1', '43', '50000', '500', '2019-11-04', '2019-11-04 21:11:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('384', '10', '43', '20000', '200', '2019-11-04', '2019-11-04 21:12:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('385', '4', '43', '20000', '200', '2019-11-04', '2019-11-04 21:12:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('386', '4', '43', '20000', '200', '2019-11-04', '2019-11-04 21:12:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('387', '12', '43', '20000', '400', '2019-11-04', '2019-11-04 21:12:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('388', '3', '43', '20000', '200', '2019-11-04', '2019-11-04 21:13:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('389', '6', '43', '30000', '300', '2019-11-04', '2019-11-04 21:13:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('390', '7', '43', '30000', '300', '2019-11-04', '2019-11-04 21:13:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('391', '5', '43', '20000', '200', '2019-11-04', '2019-11-04 21:13:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('392', '9', '43', '10000', '200', '2019-11-04', '2019-11-04 21:13:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('393', '2', '43', '20000', '400', '2019-11-04', '2019-11-04 21:14:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('394', '11', '43', '20000', '600', '2019-11-04', '2019-11-04 21:14:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('395', '8', '43', '50000', '1000', '2019-11-04', '2019-11-04 21:14:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('396', '1', '43', '50000', '1000', '2019-11-05', '2019-11-05 22:03:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('397', '8', '43', '50000', '500', '2019-11-05', '2019-11-05 22:04:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('398', '9', '43', '10000', '100', '2019-11-05', '2019-11-05 22:04:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('399', '2', '43', '20000', '200', '2019-11-05', '2019-11-05 22:05:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('400', '5', '43', '20000', '200', '2019-11-05', '2019-11-05 22:05:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('401', '7', '43', '30000', '300', '2019-11-05', '2019-11-05 22:06:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('402', '6', '43', '30000', '300', '2019-11-05', '2019-11-05 22:06:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('403', '10', '43', '20000', '200', '2019-11-05', '2019-11-05 22:06:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('404', '4', '43', '20000', '200', '2019-11-05', '2019-11-05 22:06:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('405', '12', '43', '20000', '200', '2019-11-05', '2019-11-05 22:07:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('406', '3', '43', '20000', '200', '2019-11-05', '2019-11-05 22:07:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('407', '11', '43', '20000', '200', '2019-11-05', '2019-11-05 22:07:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('408', '8', '43', '50000', '500', '2019-11-06', '2019-11-06 21:47:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('409', '2', '43', '20000', '200', '2019-11-06', '2019-11-06 21:48:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('410', '9', '43', '10000', '100', '2019-11-06', '2019-11-06 21:48:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('411', '6', '43', '30000', '300', '2019-11-06', '2019-11-06 21:48:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('412', '7', '43', '30000', '300', '2019-11-06', '2019-11-06 21:48:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('413', '10', '43', '20000', '200', '2019-11-06', '2019-11-06 21:48:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('414', '5', '43', '20000', '200', '2019-11-06', '2019-11-06 21:48:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('415', '11', '43', '20000', '200', '2019-11-06', '2019-11-06 21:48:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('416', '1', '43', '50000', '500', '2019-11-06', '2019-11-06 21:49:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('417', '12', '43', '20000', '200', '2019-11-06', '2019-11-06 21:49:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('418', '4', '43', '20000', '200', '2019-11-06', '2019-11-06 21:49:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('419', '3', '43', '20000', '200', '2019-11-06', '2019-11-06 21:49:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('420', '11', '43', '20000', '400', '2019-11-06', '2019-11-06 21:50:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('421', '1', '43', '50000', '500', '2019-11-07', '2019-11-08 13:07:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('422', '10', '43', '20000', '200', '2019-11-07', '2019-11-08 13:07:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('423', '4', '43', '20000', '200', '2019-11-07', '2019-11-08 13:07:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('424', '3', '43', '20000', '200', '2019-11-07', '2019-11-08 13:07:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('425', '6', '43', '30000', '300', '2019-11-07', '2019-11-08 13:07:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('426', '7', '43', '30000', '300', '2019-11-07', '2019-11-08 13:07:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('427', '5', '43', '20000', '200', '2019-11-07', '2019-11-08 13:07:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('428', '12', '43', '20000', '200', '2019-11-07', '2019-11-08 13:08:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('429', '2', '43', '20000', '200', '2019-11-07', '2019-11-08 13:08:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('430', '9', '43', '10000', '100', '2019-11-07', '2019-11-08 13:08:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('431', '8', '43', '50000', '500', '2019-11-07', '2019-11-08 13:08:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('432', '1', '43', '50000', '500', '2019-11-08', '2019-11-09 01:01:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('433', '10', '43', '20000', '200', '2019-11-08', '2019-11-09 01:02:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('434', '4', '43', '20000', '200', '2019-11-08', '2019-11-09 01:02:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('435', '3', '43', '20000', '200', '2019-11-08', '2019-11-09 01:02:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('436', '6', '43', '30000', '300', '2019-11-08', '2019-11-09 01:02:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('437', '7', '43', '30000', '300', '2019-11-08', '2019-11-09 01:02:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('438', '5', '43', '20000', '200', '2019-11-08', '2019-11-09 01:02:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('439', '12', '43', '20000', '200', '2019-11-08', '2019-11-09 01:02:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('440', '8', '43', '50000', '500', '2019-11-08', '2019-11-09 01:02:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('441', '1', '43', '50000', '500', '2019-11-09', '2019-11-10 01:52:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('442', '10', '43', '20000', '200', '2019-11-09', '2019-11-10 01:52:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('443', '4', '43', '20000', '200', '2019-11-09', '2019-11-10 01:52:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('444', '3', '43', '20000', '200', '2019-11-09', '2019-11-10 01:53:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('445', '7', '43', '30000', '300', '2019-11-09', '2019-11-10 01:53:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('446', '6', '43', '30000', '300', '2019-11-09', '2019-11-10 01:53:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('447', '5', '43', '20000', '200', '2019-11-09', '2019-11-10 01:53:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('448', '2', '43', '20000', '600', '2019-11-09', '2019-11-10 01:53:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('449', '9', '43', '10000', '300', '2019-11-09', '2019-11-10 01:54:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('450', '8', '43', '50000', '500', '2019-11-09', '2019-11-10 01:54:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('451', '8', '43', '50000', '1000', '2019-11-11', '2019-11-11 23:27:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('452', '11', '43', '20000', '1000', '2019-11-11', '2019-11-11 23:27:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('453', '2', '43', '20000', '600', '2019-11-11', '2019-11-11 23:27:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('454', '9', '43', '10000', '300', '2019-11-11', '2019-11-11 23:28:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('455', '10', '43', '20000', '400', '2019-11-11', '2019-11-11 23:28:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('456', '3', '43', '20000', '200', '2019-11-11', '2019-11-11 23:28:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('457', '6', '43', '30000', '600', '2019-11-11', '2019-11-11 23:28:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('458', '7', '43', '30000', '300', '2019-11-11', '2019-11-11 23:28:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('459', '4', '43', '20000', '400', '2019-11-11', '2019-11-11 23:28:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('460', '5', '43', '20000', '200', '2019-11-11', '2019-11-11 23:28:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('461', '12', '43', '20000', '400', '2019-11-11', '2019-11-11 23:29:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('462', '13', '43', '10000', '100', '2019-11-11', '2019-11-11 23:29:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('463', '1', '43', '50000', '500', '2019-11-12', '2019-11-12 20:30:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('464', '10', '43', '20000', '200', '2019-11-12', '2019-11-12 20:30:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('465', '13', '43', '10000', '100', '2019-11-12', '2019-11-12 20:30:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('466', '4', '43', '20000', '200', '2019-11-12', '2019-11-12 20:30:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('467', '3', '43', '20000', '600', '2019-11-12', '2019-11-12 20:31:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('468', '12', '43', '20000', '200', '2019-11-12', '2019-11-12 20:31:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('469', '6', '43', '30000', '300', '2019-11-12', '2019-11-12 20:31:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('470', '7', '43', '30000', '300', '2019-11-12', '2019-11-12 20:31:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('471', '5', '43', '20000', '200', '2019-11-12', '2019-11-12 20:31:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('472', '2', '43', '20000', '200', '2019-11-12', '2019-11-12 20:31:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('473', '9', '43', '10000', '100', '2019-11-12', '2019-11-12 20:31:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('474', '8', '43', '50000', '500', '2019-11-12', '2019-11-12 20:32:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('475', '1', '43', '50000', '500', '2019-11-13', '2019-11-13 19:31:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('476', '10', '43', '20000', '200', '2019-11-13', '2019-11-13 19:31:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('477', '13', '43', '10000', '100', '2019-11-13', '2019-11-13 19:31:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('478', '5', '43', '20000', '200', '2019-11-13', '2019-11-13 19:31:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('479', '12', '43', '20000', '200', '2019-11-13', '2019-11-13 19:32:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('480', '6', '43', '30000', '300', '2019-11-13', '2019-11-13 19:32:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('481', '7', '43', '30000', '300', '2019-11-13', '2019-11-13 19:32:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('482', '5', '43', '20000', '200', '2019-11-13', '2019-11-13 19:32:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('483', '2', '43', '20000', '200', '2019-11-13', '2019-11-13 19:32:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('484', '9', '43', '10000', '100', '2019-11-13', '2019-11-13 19:32:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('485', '8', '43', '50000', '500', '2019-11-13', '2019-11-13 19:32:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('486', '11', '43', '20000', '1000', '2019-11-13', '2019-11-13 19:33:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('487', '1', '43', '50000', '1000', '2019-11-14', '2019-11-14 20:45:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('488', '10', '43', '20000', '200', '2019-11-14', '2019-11-14 20:46:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('489', '13', '43', '10000', '100', '2019-11-14', '2019-11-14 20:46:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('490', '4', '43', '20000', '200', '2019-11-14', '2019-11-14 20:54:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('491', '12', '43', '20000', '200', '2019-11-14', '2019-11-14 20:54:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('492', '3', '43', '20000', '400', '2019-11-14', '2019-11-14 20:54:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('493', '6', '43', '30000', '300', '2019-11-14', '2019-11-14 20:54:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('494', '7', '43', '30000', '300', '2019-11-14', '2019-11-14 20:54:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('495', '5', '43', '20000', '200', '2019-11-14', '2019-11-14 20:55:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('496', '9', '43', '10000', '100', '2019-11-14', '2019-11-14 20:55:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('497', '2', '43', '20000', '200', '2019-11-14', '2019-11-14 20:55:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('498', '8', '43', '50000', '500', '2019-11-14', '2019-11-14 20:55:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('499', '1', '43', '50000', '500', '2019-11-15', '2019-11-15 20:17:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('500', '2', '43', '20000', '200', '2019-11-15', '2019-11-15 20:18:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('501', '3', '43', '20000', '200', '2019-11-15', '2019-11-15 20:18:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('502', '4', '43', '20000', '200', '2019-11-15', '2019-11-15 20:18:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('503', '5', '43', '20000', '200', '2019-11-15', '2019-11-15 20:18:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('504', '6', '43', '30000', '300', '2019-11-15', '2019-11-15 20:19:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('505', '7', '43', '30000', '300', '2019-11-15', '2019-11-15 20:20:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('506', '8', '43', '50000', '500', '2019-11-15', '2019-11-15 20:20:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('507', '9', '43', '10000', '100', '2019-11-15', '2019-11-15 20:20:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('508', '10', '43', '20000', '200', '2019-11-15', '2019-11-15 20:21:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('509', '12', '43', '20000', '200', '2019-11-15', '2019-11-15 20:21:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('510', '13', '43', '10000', '100', '2019-11-15', '2019-11-15 20:21:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('511', '14', '43', '30000', '300', '2019-11-15', '2019-11-15 20:24:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('512', '1', '43', '50000', '500', '2019-11-16', '2019-11-17 21:22:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('513', '2', '43', '20000', '200', '2019-11-16', '2019-11-17 21:22:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('514', '9', '43', '10000', '100', '2019-11-16', '2019-11-17 21:22:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('515', '6', '43', '30000', '300', '2019-11-16', '2019-11-17 21:22:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('516', '10', '43', '20000', '200', '2019-11-16', '2019-11-17 21:23:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('517', '13', '43', '10000', '100', '2019-11-16', '2019-11-17 21:23:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('518', '4', '43', '20000', '200', '2019-11-16', '2019-11-17 21:23:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('519', '7', '43', '30000', '300', '2019-11-16', '2019-11-17 21:23:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('520', '14', '43', '30000', '300', '2019-11-16', '2019-11-17 21:23:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('521', '3', '43', '20000', '200', '2019-11-16', '2019-11-17 21:23:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('522', '5', '43', '20000', '200', '2019-11-16', '2019-11-17 21:23:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('523', '8', '43', '50000', '500', '2019-11-16', '2019-11-17 21:24:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('524', '7', '43', '30000', '300', '2019-11-17', '2019-11-17 21:24:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('525', '8', '43', '50000', '500', '2019-11-17', '2019-11-17 21:24:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('526', '6', '43', '30000', '300', '2019-11-17', '2019-11-17 21:24:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('527', '1', '43', '50000', '500', '2019-11-18', '2019-11-18 20:07:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('528', '10', '43', '20000', '400', '2019-11-18', '2019-11-18 20:07:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('529', '13', '43', '10000', '200', '2019-11-18', '2019-11-18 20:08:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('530', '4', '43', '20000', '400', '2019-11-18', '2019-11-18 20:08:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('531', '3', '43', '20000', '200', '2019-11-18', '2019-11-18 20:08:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('532', '12', '43', '20000', '600', '2019-11-18', '2019-11-18 20:08:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('533', '14', '43', '30000', '600', '2019-11-18', '2019-11-18 20:09:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('534', '6', '43', '30000', '300', '2019-11-18', '2019-11-18 20:09:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('535', '7', '43', '30000', '300', '2019-11-18', '2019-11-18 20:09:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('536', '5', '43', '20000', '400', '2019-11-18', '2019-11-18 20:09:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('537', '2', '43', '20000', '400', '2019-11-18', '2019-11-18 20:09:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('538', '9', '43', '10000', '200', '2019-11-18', '2019-11-18 20:10:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('539', '8', '43', '50000', '500', '2019-11-18', '2019-11-18 20:10:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('540', '1', '43', '50000', '500', '2019-11-19', '2019-11-19 18:36:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('541', '10', '43', '20000', '200', '2019-11-19', '2019-11-19 18:36:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('542', '13', '43', '10000', '100', '2019-11-19', '2019-11-19 18:36:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('543', '4', '43', '20000', '200', '2019-11-19', '2019-11-19 18:37:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('544', '12', '43', '20000', '200', '2019-11-19', '2019-11-19 18:37:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('545', '14', '43', '30000', '300', '2019-11-19', '2019-11-19 18:37:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('546', '3', '43', '20000', '200', '2019-11-19', '2019-11-19 18:37:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('547', '6', '43', '30000', '300', '2019-11-19', '2019-11-19 18:38:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('548', '7', '43', '30000', '300', '2019-11-19', '2019-11-19 18:38:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('549', '5', '43', '20000', '200', '2019-11-19', '2019-11-19 18:38:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('550', '11', '43', '20000', '1000', '2019-11-19', '2019-11-19 18:38:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('551', '2', '43', '20000', '200', '2019-11-19', '2019-11-19 18:39:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('552', '9', '43', '10000', '100', '2019-11-19', '2019-11-19 18:39:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('553', '8', '43', '50000', '500', '2019-11-19', '2019-11-19 18:39:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('554', '1', '43', '50000', '2000', '2019-11-21', '2019-11-21 18:23:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('555', '10', '43', '20000', '200', '2019-11-21', '2019-11-21 18:23:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('556', '13', '43', '10000', '100', '2019-11-21', '2019-11-21 18:23:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('557', '4', '43', '20000', '200', '2019-11-21', '2019-11-21 18:24:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('558', '12', '43', '20000', '200', '2019-11-21', '2019-11-21 18:24:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('559', '14', '43', '30000', '300', '2019-11-21', '2019-11-21 18:24:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('560', '3', '43', '20000', '200', '2019-11-21', '2019-11-21 18:25:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('561', '6', '43', '30000', '300', '2019-11-21', '2019-11-21 18:25:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('562', '7', '43', '30000', '300', '2019-11-21', '2019-11-21 18:25:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('563', '5', '43', '20000', '200', '2019-11-21', '2019-11-21 18:25:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('564', '11', '43', '20000', '200', '2019-11-21', '2019-11-21 18:26:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('565', '8', '43', '50000', '500', '2019-11-21', '2019-11-21 18:26:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('566', '10', '43', '20000', '200', '2019-11-20', '2019-11-21 18:27:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('567', '13', '43', '10000', '100', '2019-11-20', '2019-11-21 18:27:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('568', '4', '43', '20000', '200', '2019-11-20', '2019-11-21 18:27:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('569', '14', '43', '30000', '300', '2019-11-20', '2019-11-21 18:27:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('570', '3', '43', '20000', '400', '2019-11-20', '2019-11-21 18:27:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('571', '6', '43', '30000', '300', '2019-11-20', '2019-11-21 18:27:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('572', '7', '43', '30000', '300', '2019-11-20', '2019-11-21 18:28:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('573', '5', '43', '20000', '200', '2019-11-20', '2019-11-21 18:28:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('574', '2', '43', '20000', '200', '2019-11-20', '2019-11-21 18:28:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('575', '9', '43', '10000', '100', '2019-11-20', '2019-11-21 18:28:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('576', '8', '43', '50000', '500', '2019-11-20', '2019-11-21 18:28:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('577', '12', '43', '20000', '200', '2019-11-20', '2019-11-21 18:29:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('578', '1', '43', '50000', '1000', '2019-11-22', '2019-11-22 20:07:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('580', '10', '43', '20000', '200', '2019-11-22', '2019-11-22 20:08:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('581', '13', '43', '10000', '100', '2019-11-22', '2019-11-22 20:08:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('582', '4', '43', '20000', '200', '2019-11-22', '2019-11-22 20:08:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('583', '12', '43', '20000', '200', '2019-11-22', '2019-11-22 20:08:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('584', '14', '43', '30000', '300', '2019-11-22', '2019-11-22 20:08:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('585', '3', '43', '20000', '200', '2019-11-22', '2019-11-22 20:09:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('586', '6', '43', '30000', '300', '2019-11-22', '2019-11-22 20:09:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('587', '7', '43', '30000', '300', '2019-11-22', '2019-11-22 20:09:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('588', '2', '43', '20000', '400', '2019-11-22', '2019-11-22 20:09:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('589', '9', '43', '10000', '200', '2019-11-22', '2019-11-22 20:10:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('590', '5', '43', '20000', '200', '2019-11-22', '2019-11-22 20:10:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('591', '8', '43', '50000', '500', '2019-11-22', '2019-11-22 20:10:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('592', '1', '43', '50000', '500', '2019-11-23', '2019-11-23 21:35:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('593', '10', '43', '20000', '200', '2019-11-23', '2019-11-23 21:35:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('594', '13', '43', '10000', '100', '2019-11-23', '2019-11-23 21:35:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('595', '4', '43', '20000', '200', '2019-11-23', '2019-11-23 21:35:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('596', '12', '43', '20000', '200', '2019-11-23', '2019-11-23 21:35:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('597', '14', '43', '30000', '300', '2019-11-23', '2019-11-23 21:36:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('598', '3', '43', '20000', '200', '2019-11-23', '2019-11-23 21:36:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('599', '6', '43', '30000', '300', '2019-11-23', '2019-11-23 21:36:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('600', '2', '43', '20000', '200', '2019-11-23', '2019-11-23 21:36:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('601', '9', '43', '10000', '100', '2019-11-23', '2019-11-23 21:36:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('602', '8', '43', '50000', '500', '2019-11-23', '2019-11-23 21:37:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('603', '10', '43', '20000', '200', '2019-11-24', '2019-11-24 20:37:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('604', '6', '43', '30000', '300', '2019-11-24', '2019-11-24 20:37:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('605', '13', '43', '10000', '100', '2019-11-24', '2019-11-24 20:37:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('606', '1', '43', '50000', '1000', '2019-11-25', '2019-11-25 18:14:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('607', '10', '43', '20000', '200', '2019-11-25', '2019-11-25 18:15:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('608', '13', '43', '10000', '100', '2019-11-25', '2019-11-25 18:15:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('609', '4', '43', '20000', '400', '2019-11-25', '2019-11-25 18:15:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('610', '12', '43', '20000', '400', '2019-11-25', '2019-11-25 18:15:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('611', '14', '43', '30000', '600', '2019-11-25', '2019-11-25 18:15:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('612', '3', '43', '20000', '200', '2019-11-25', '2019-11-25 18:16:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('613', '6', '43', '30000', '300', '2019-11-25', '2019-11-25 18:16:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('614', '7', '43', '30000', '300', '2019-11-25', '2019-11-25 18:16:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('615', '5', '43', '20000', '200', '2019-11-25', '2019-11-25 18:16:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('616', '11', '43', '20000', '1000', '2019-11-25', '2019-11-25 18:17:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('617', '2', '43', '20000', '400', '2019-11-25', '2019-11-25 18:17:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('618', '9', '43', '10000', '200', '2019-11-25', '2019-11-25 18:17:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('619', '8', '43', '50000', '1000', '2019-11-25', '2019-11-25 18:18:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('620', '1', '43', '50000', '500', '2019-11-26', '2019-11-27 21:38:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('621', '10', '43', '20000', '200', '2019-11-26', '2019-11-27 21:39:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('622', '13', '43', '10000', '100', '2019-11-26', '2019-11-27 21:39:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('623', '4', '43', '20000', '200', '2019-11-26', '2019-11-27 21:39:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('624', '12', '43', '20000', '200', '2019-11-26', '2019-11-27 21:39:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('625', '14', '43', '30000', '300', '2019-11-26', '2019-11-27 21:39:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('626', '3', '43', '20000', '200', '2019-11-26', '2019-11-27 21:39:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('627', '6', '43', '30000', '300', '2019-11-26', '2019-11-27 21:40:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('628', '5', '43', '20000', '400', '2019-11-26', '2019-11-27 21:40:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('629', '2', '43', '20000', '200', '2019-11-26', '2019-11-27 21:40:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('630', '9', '43', '10000', '100', '2019-11-26', '2019-11-27 21:40:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('631', '8', '43', '50000', '500', '2019-11-26', '2019-11-27 21:40:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('632', '1', '43', '50000', '500', '2019-11-27', '2019-11-27 21:41:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('633', '10', '43', '20000', '200', '2019-11-27', '2019-11-27 21:41:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('634', '13', '43', '10000', '100', '2019-11-27', '2019-11-27 21:41:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('635', '4', '43', '20000', '200', '2019-11-27', '2019-11-27 21:41:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('636', '12', '43', '20000', '200', '2019-11-27', '2019-11-27 21:41:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('637', '14', '43', '30000', '300', '2019-11-27', '2019-11-27 21:42:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('638', '3', '43', '20000', '200', '2019-11-27', '2019-11-27 21:42:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('639', '6', '43', '30000', '300', '2019-11-27', '2019-11-27 21:42:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('640', '7', '43', '30000', '300', '2019-11-27', '2019-11-27 21:42:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('641', '5', '43', '20000', '200', '2019-11-27', '2019-11-27 21:42:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('642', '8', '43', '50000', '500', '2019-11-27', '2019-11-27 21:42:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('643', '1', '43', '50000', '500', '2019-11-28', '2019-11-30 19:59:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('644', '10', '43', '20000', '200', '2019-11-28', '2019-11-30 19:59:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('645', '13', '43', '10000', '100', '2019-11-28', '2019-11-30 20:00:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('646', '4', '43', '20000', '200', '2019-11-28', '2019-11-30 20:00:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('647', '12', '43', '20000', '200', '2019-11-28', '2019-11-30 20:00:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('648', '14', '43', '30000', '300', '2019-11-28', '2019-11-30 20:00:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('649', '3', '43', '20000', '200', '2019-11-28', '2019-11-30 20:00:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('650', '6', '43', '30000', '300', '2019-11-28', '2019-11-30 20:01:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('651', '7', '43', '30000', '300', '2019-11-28', '2019-11-30 20:01:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('652', '5', '43', '20000', '200', '2019-11-28', '2019-11-30 20:01:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('653', '8', '43', '50000', '500', '2019-11-28', '2019-11-30 20:01:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('654', '1', '43', '50000', '500', '2019-11-29', '2019-11-30 20:02:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('655', '10', '43', '20000', '200', '2019-11-29', '2019-11-30 20:05:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('656', '13', '43', '10000', '100', '2019-11-29', '2019-11-30 20:05:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('657', '4', '43', '20000', '200', '2019-11-29', '2019-11-30 20:06:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('658', '12', '43', '20000', '200', '2019-11-29', '2019-11-30 20:06:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('659', '14', '43', '30000', '300', '2019-11-29', '2019-11-30 20:06:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('660', '6', '43', '30000', '300', '2019-11-29', '2019-11-30 20:06:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('661', '7', '43', '30000', '300', '2019-11-29', '2019-11-30 20:06:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('662', '5', '43', '20000', '200', '2019-11-29', '2019-11-30 20:06:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('663', '8', '43', '50000', '500', '2019-11-29', '2019-11-30 20:07:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('664', '1', '43', '50000', '500', '2019-11-30', '2019-11-30 20:07:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('665', '10', '43', '20000', '200', '2019-11-30', '2019-11-30 20:07:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('666', '13', '43', '10000', '100', '2019-11-30', '2019-11-30 20:07:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('667', '4', '43', '20000', '200', '2019-11-30', '2019-11-30 20:07:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('668', '12', '43', '20000', '200', '2019-11-30', '2019-11-30 20:07:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('670', '3', '43', '20000', '400', '2019-11-30', '2019-11-30 20:08:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('671', '6', '43', '30000', '300', '2019-11-30', '2019-11-30 20:08:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('672', '7', '43', '30000', '300', '2019-11-30', '2019-11-30 20:08:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('673', '5', '43', '20000', '200', '2019-11-30', '2019-11-30 20:08:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('674', '2', '43', '20000', '600', '2019-11-30', '2019-11-30 20:08:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('675', '9', '43', '10000', '300', '2019-11-30', '2019-11-30 20:08:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('676', '8', '43', '50000', '500', '2019-11-30', '2019-11-30 20:09:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('677', '12', '43', '20000', '400', '2019-12-02', '2019-12-02 17:53:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('678', '1', '43', '50000', '500', '2019-12-02', '2019-12-02 18:04:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('679', '10', '43', '20000', '200', '2019-12-02', '2019-12-02 18:04:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('680', '10', '43', '20000', '200', '2019-12-02', '2019-12-02 18:04:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('681', '13', '43', '10000', '200', '2019-12-02', '2019-12-02 18:04:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('682', '4', '43', '20000', '400', '2019-12-02', '2019-12-02 18:04:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('683', '14', '43', '30000', '600', '2019-12-02', '2019-12-02 18:04:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('684', '3', '43', '20000', '400', '2019-12-02', '2019-12-02 18:05:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('685', '6', '43', '30000', '600', '2019-12-02', '2019-12-02 18:05:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('686', '7', '43', '30000', '600', '2019-12-02', '2019-12-02 18:05:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('687', '5', '43', '20000', '200', '2019-12-02', '2019-12-02 18:05:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('688', '2', '43', '20000', '400', '2019-12-02', '2019-12-02 18:05:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('689', '9', '43', '10000', '200', '2019-12-02', '2019-12-02 18:05:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('690', '8', '43', '50000', '500', '2019-12-02', '2019-12-02 18:06:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('691', '1', '43', '50000', '500', '2019-12-03', '2019-12-03 23:09:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('692', '10', '43', '20000', '200', '2019-12-03', '2019-12-03 23:10:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('693', '13', '43', '10000', '100', '2019-12-03', '2019-12-03 23:10:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('694', '4', '43', '20000', '200', '2019-12-03', '2019-12-03 23:10:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('695', '12', '43', '20000', '200', '2019-12-03', '2019-12-03 23:10:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('696', '14', '43', '30000', '300', '2019-12-03', '2019-12-03 23:10:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('697', '6', '43', '30000', '300', '2019-12-03', '2019-12-03 23:11:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('698', '7', '43', '30000', '300', '2019-12-03', '2019-12-03 23:11:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('699', '5', '43', '20000', '200', '2019-12-03', '2019-12-03 23:11:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('700', '8', '43', '50000', '500', '2019-12-03', '2019-12-03 23:12:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('701', '11', '43', '20000', '1000', '2019-12-03', '2019-12-03 23:12:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('702', '1', '43', '50000', '1000', '2019-12-04', '2019-12-05 02:57:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('703', '10', '43', '20000', '200', '2019-12-04', '2019-12-05 02:58:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('704', '13', '43', '10000', '100', '2019-12-04', '2019-12-05 02:58:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('705', '4', '43', '20000', '200', '2019-12-04', '2019-12-05 02:58:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('706', '12', '43', '20000', '200', '2019-12-04', '2019-12-05 02:58:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('707', '14', '43', '30000', '300', '2019-12-04', '2019-12-05 02:59:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('708', '6', '43', '30000', '300', '2019-12-04', '2019-12-05 02:59:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('709', '7', '43', '30000', '300', '2019-12-04', '2019-12-05 02:59:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('710', '5', '43', '20000', '200', '2019-12-04', '2019-12-05 02:59:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('711', '2', '43', '20000', '200', '2019-12-04', '2019-12-05 02:59:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('712', '9', '43', '10000', '100', '2019-12-04', '2019-12-05 02:59:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('713', '8', '43', '50000', '1000', '2019-12-04', '2019-12-05 03:00:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('714', '15', '43', '30000', '1800', '2019-12-04', '2019-12-05 03:00:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('715', '1', '43', '50000', '500', '2019-12-05', '2019-12-05 21:13:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('716', '12', '43', '20000', '200', '2019-12-05', '2019-12-05 21:13:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('717', '10', '43', '20000', '200', '2019-12-05', '2019-12-05 21:45:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('718', '13', '43', '10000', '100', '2019-12-05', '2019-12-05 21:45:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('719', '4', '43', '20000', '200', '2019-12-05', '2019-12-05 21:46:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('720', '14', '43', '30000', '300', '2019-12-05', '2019-12-05 21:46:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('721', '3', '43', '20000', '800', '2019-12-05', '2019-12-05 21:46:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('722', '6', '43', '30000', '300', '2019-12-05', '2019-12-05 21:46:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('723', '7', '43', '30000', '300', '2019-12-05', '2019-12-05 21:47:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('724', '2', '43', '20000', '200', '2019-12-05', '2019-12-05 21:47:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('725', '9', '43', '10000', '100', '2019-12-05', '2019-12-05 21:47:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('726', '8', '43', '50000', '500', '2019-12-05', '2019-12-05 21:48:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('727', '12', '43', '20000', '17200', '2019-12-05', '2019-12-05 21:52:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('728', '3', '43', '20000', '200', '2019-12-08', '2019-12-09 22:21:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('729', '6', '43', '30000', '300', '2019-12-08', '2019-12-09 22:21:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('730', '7', '43', '30000', '300', '2019-12-08', '2019-12-09 22:21:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('731', '5', '43', '20000', '200', '2019-12-08', '2019-12-09 22:21:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('732', '11', '43', '20000', '200', '2019-12-08', '2019-12-09 22:22:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('733', '2', '43', '20000', '200', '2019-12-08', '2019-12-09 22:22:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('734', '9', '43', '10000', '100', '2019-12-08', '2019-12-09 22:22:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('735', '1', '43', '50000', '1000', '2019-12-09', '2019-12-09 22:26:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('736', '10', '43', '20000', '400', '2019-12-09', '2019-12-09 22:26:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('737', '13', '43', '10000', '200', '2019-12-09', '2019-12-09 22:26:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('738', '4', '43', '20000', '400', '2019-12-09', '2019-12-09 22:26:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('739', '17', '43', '50000', '1000', '2019-12-09', '2019-12-09 22:27:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('740', '19', '43', '10000', '200', '2019-12-09', '2019-12-09 22:27:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('741', '14', '43', '30000', '300', '2019-12-09', '2019-12-09 22:27:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('742', '3', '43', '20000', '400', '2019-12-09', '2019-12-09 22:27:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('743', '6', '43', '30000', '300', '2019-12-09', '2019-12-09 22:27:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('744', '7', '43', '30000', '300', '2019-12-09', '2019-12-09 22:28:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('745', '5', '43', '20000', '200', '2019-12-09', '2019-12-09 22:28:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('746', '11', '43', '20000', '200', '2019-12-09', '2019-12-09 22:28:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('747', '2', '43', '20000', '200', '2019-12-09', '2019-12-09 22:28:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('748', '9', '43', '10000', '100', '2019-12-09', '2019-12-09 22:28:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('749', '8', '43', '50000', '1000', '2019-12-09', '2019-12-09 22:29:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('750', '3', '43', '20000', '600', '2019-12-13', '2019-12-13 17:55:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('752', '7', '43', '30000', '300', '2019-12-13', '2019-12-13 17:58:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('753', '5', '43', '20000', '600', '2019-12-13', '2019-12-13 17:58:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('754', '11', '43', '20000', '1000', '2019-12-13', '2019-12-13 17:59:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('755', '8', '43', '50000', '1000', '2019-12-13', '2019-12-13 17:59:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('756', '1', '43', '50000', '2000', '2019-12-13', '2019-12-13 18:00:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('757', '10', '43', '20000', '600', '2019-12-13', '2019-12-13 18:00:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('758', '13', '43', '10000', '2000', '2019-12-13', '2019-12-13 18:00:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('760', '4', '43', '20000', '400', '2019-12-13', '2019-12-13 18:01:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('762', '17', '43', '50000', '2000', '2019-12-13', '2019-12-13 18:01:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('763', '19', '43', '10000', '400', '2019-12-13', '2019-12-13 18:02:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('764', '14', '43', '30000', '600', '2019-12-13', '2019-12-13 18:02:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('765', '2', '43', '20000', '200', '2019-12-13', '2019-12-13 18:02:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('766', '9', '43', '10000', '100', '2019-12-13', '2019-12-13 18:02:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('767', '6', '43', '30000', '1200', '2019-12-13', '2019-12-13 18:08:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('769', '1', '43', '50000', '1000', '2019-12-06', '2019-12-15 13:16:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('770', '10', '43', '20000', '200', '2019-12-06', '2019-12-15 13:16:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('771', '13', '43', '10000', '100', '2019-12-06', '2019-12-15 13:16:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('772', '4', '43', '20000', '200', '2019-12-06', '2019-12-15 13:17:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('773', '17', '43', '50000', '500', '2019-12-06', '2019-12-15 13:17:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('774', '14', '43', '30000', '300', '2019-12-06', '2019-12-15 13:17:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('775', '3', '43', '20000', '200', '2019-12-06', '2019-12-15 13:17:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('776', '6', '43', '30000', '300', '2019-12-06', '2019-12-15 13:17:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('777', '7', '43', '30000', '300', '2019-12-06', '2019-12-15 13:18:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('778', '5', '43', '20000', '200', '2019-12-06', '2019-12-15 13:18:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('779', '11', '43', '20000', '200', '2019-12-06', '2019-12-15 13:18:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('780', '15', '43', '30000', '600', '2019-12-06', '2019-12-15 13:19:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('781', '8', '43', '50000', '500', '2019-12-06', '2019-12-15 13:19:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('782', '16', '43', '10000', '200', '2019-12-06', '2019-12-15 13:19:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('783', '1', '43', '50000', '500', '2019-12-07', '2019-12-15 13:20:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('784', '10', '43', '20000', '200', '2019-12-07', '2019-12-15 13:20:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('785', '13', '43', '10000', '100', '2019-12-07', '2019-12-15 13:20:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('786', '4', '43', '20000', '200', '2019-12-07', '2019-12-15 13:20:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('787', '17', '43', '50000', '500', '2019-12-07', '2019-12-15 13:21:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('788', '14', '43', '30000', '300', '2019-12-07', '2019-12-15 13:21:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('789', '3', '43', '20000', '200', '2019-12-07', '2019-12-15 13:21:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('790', '6', '43', '30000', '300', '2019-12-07', '2019-12-15 13:21:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('791', '7', '43', '30000', '300', '2019-12-07', '2019-12-15 13:21:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('792', '5', '43', '20000', '200', '2019-12-07', '2019-12-15 13:21:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('793', '11', '43', '20000', '200', '2019-12-07', '2019-12-15 13:22:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('794', '8', '43', '50000', '1000', '2019-12-07', '2019-12-15 13:22:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('795', '2', '43', '20000', '200', '2019-12-07', '2019-12-15 13:22:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('796', '9', '43', '10000', '100', '2019-12-07', '2019-12-15 13:22:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('797', '4', '43', '20000', '400', '2019-11-13', '2019-12-15 15:34:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('798', '7', '43', '30000', '300', '2019-11-13', '2019-12-15 15:35:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('799', '8', '43', '50000', '1000', '2019-11-13', '2019-12-15 15:35:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('800', '11', '43', '20000', '1000', '2019-11-13', '2019-12-15 15:35:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('801', '10', '43', '20000', '200', '2019-12-14', '2019-12-16 15:16:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('802', '4', '43', '20000', '400', '2019-12-14', '2019-12-16 15:16:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('803', '17', '43', '50000', '500', '2019-12-14', '2019-12-16 15:16:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('804', '14', '43', '30000', '300', '2019-12-14', '2019-12-16 15:17:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('805', '3', '43', '20000', '200', '2019-12-14', '2019-12-16 15:17:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('806', '6', '43', '30000', '300', '2019-12-14', '2019-12-16 15:17:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('807', '7', '43', '30000', '300', '2019-12-14', '2019-12-16 15:17:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('808', '5', '43', '20000', '200', '2019-12-14', '2019-12-16 15:17:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('809', '15', '43', '30000', '1200', '2019-12-14', '2019-12-16 15:17:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('810', '8', '43', '50000', '1000', '2019-12-14', '2019-12-16 15:18:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('811', '2', '43', '20000', '200', '2019-12-14', '2019-12-16 15:18:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('812', '9', '43', '10000', '100', '2019-12-14', '2019-12-16 15:18:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('813', '19', '43', '10000', '200', '2019-12-14', '2019-12-16 15:18:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('815', '10', '43', '20000', '600', '2019-12-16', '2019-12-17 00:18:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('816', '4', '43', '20000', '400', '2019-12-16', '2019-12-17 00:18:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('817', '14', '43', '30000', '600', '2019-12-16', '2019-12-17 00:18:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('818', '6', '43', '30000', '600', '2019-12-16', '2019-12-17 00:18:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('819', '7', '43', '30000', '2100', '2019-12-16', '2019-12-17 00:19:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('820', '5', '43', '20000', '400', '2019-12-16', '2019-12-17 00:19:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('821', '8', '43', '50000', '1000', '2019-12-16', '2019-12-17 00:19:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('822', '19', '43', '10000', '200', '2019-12-16', '2019-12-17 00:19:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('823', '10', '43', '20000', '200', '2019-12-17', '2019-12-17 20:01:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('824', '13', '43', '10000', '100', '2019-12-17', '2019-12-17 20:01:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('825', '14', '43', '30000', '600', '2019-12-17', '2019-12-17 20:02:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('826', '3', '43', '20000', '400', '2019-12-17', '2019-12-17 20:02:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('827', '6', '43', '30000', '300', '2019-12-17', '2019-12-17 20:02:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('828', '7', '43', '30000', '300', '2019-12-17', '2019-12-17 20:03:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('829', '5', '43', '20000', '400', '2019-12-17', '2019-12-17 20:03:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('830', '11', '43', '20000', '600', '2019-12-17', '2019-12-17 20:03:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('831', '15', '43', '30000', '900', '2019-12-17', '2019-12-17 20:03:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('832', '8', '43', '50000', '1000', '2019-12-17', '2019-12-17 20:04:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('833', '9', '43', '10000', '500', '2019-12-17', '2019-12-17 20:04:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('834', '2', '43', '20000', '1200', '2019-12-17', '2019-12-17 20:04:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('835', '19', '43', '10000', '100', '2019-12-17', '2019-12-17 20:04:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('836', '10', '43', '20000', '200', '2019-12-18', '2019-12-18 20:26:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('837', '4', '43', '20000', '400', '2019-12-18', '2019-12-18 20:26:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('838', '14', '43', '30000', '600', '2019-12-18', '2019-12-18 20:27:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('839', '6', '43', '30000', '300', '2019-12-18', '2019-12-18 20:27:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('840', '7', '43', '30000', '300', '2019-12-18', '2019-12-18 20:27:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('841', '5', '43', '20000', '200', '2019-12-18', '2019-12-18 20:27:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('842', '11', '43', '20000', '400', '2019-12-18', '2019-12-18 20:27:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('843', '8', '43', '50000', '1000', '2019-12-18', '2019-12-18 20:27:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('844', '19', '43', '10000', '100', '2019-12-18', '2019-12-18 20:28:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('845', '10', '43', '20000', '200', '2019-12-19', '2019-12-19 20:09:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('846', '4', '43', '20000', '200', '2019-12-19', '2019-12-19 20:09:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('847', '3', '43', '20000', '600', '2019-12-19', '2019-12-19 20:09:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('848', '6', '43', '30000', '300', '2019-12-19', '2019-12-19 20:10:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('849', '7', '43', '30000', '300', '2019-12-19', '2019-12-19 20:10:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('850', '5', '43', '20000', '200', '2019-12-19', '2019-12-19 20:10:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('851', '11', '43', '20000', '400', '2019-12-19', '2019-12-19 20:10:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('852', '8', '43', '50000', '2000', '2019-12-19', '2019-12-19 20:11:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('853', '16', '43', '10000', '200', '2019-12-19', '2019-12-19 20:11:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('854', '19', '43', '10000', '100', '2019-12-19', '2019-12-19 20:12:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('855', '1', '43', '50000', '1000', '2019-12-20', '2019-12-20 21:40:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('856', '10', '43', '20000', '200', '2019-12-20', '2019-12-20 21:40:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('857', '4', '43', '20000', '200', '2019-12-20', '2019-12-20 21:40:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('858', '14', '43', '30000', '900', '2019-12-20', '2019-12-20 21:41:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('859', '3', '43', '20000', '200', '2019-12-20', '2019-12-20 21:41:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('860', '6', '43', '30000', '300', '2019-12-20', '2019-12-20 21:41:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('861', '7', '43', '30000', '300', '2019-12-20', '2019-12-20 21:41:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('862', '5', '43', '20000', '200', '2019-12-20', '2019-12-20 21:41:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('863', '8', '43', '50000', '3000', '2019-12-20', '2019-12-20 21:41:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('864', '19', '43', '10000', '100', '2019-12-20', '2019-12-20 21:41:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('865', '20', '43', '20000', '200', '2019-12-20', '2019-12-20 21:42:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('866', '1', '43', '50000', '500', '2019-12-21', '2019-12-22 21:46:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('867', '10', '43', '20000', '200', '2019-12-21', '2019-12-22 21:46:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('868', '4', '43', '20000', '200', '2019-12-21', '2019-12-22 21:46:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('869', '3', '43', '20000', '200', '2019-12-21', '2019-12-22 21:47:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('870', '6', '43', '30000', '300', '2019-12-21', '2019-12-22 21:47:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('871', '7', '43', '30000', '300', '2019-12-21', '2019-12-22 21:47:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('872', '5', '43', '20000', '200', '2019-12-21', '2019-12-22 21:48:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('873', '8', '43', '50000', '1000', '2019-12-21', '2019-12-22 21:48:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('874', '2', '43', '20000', '400', '2019-12-21', '2019-12-22 21:49:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('875', '9', '43', '10000', '400', '2019-12-21', '2019-12-22 21:50:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('876', '2', '43', '20000', '200', '2019-12-21', '2019-12-22 21:50:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('877', '19', '43', '10000', '100', '2019-12-21', '2019-12-22 21:50:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('878', '1', '43', '50000', '500', '2019-12-23', '2019-12-23 19:42:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('879', '10', '43', '20000', '400', '2019-12-23', '2019-12-23 19:42:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('880', '4', '43', '20000', '400', '2019-12-23', '2019-12-23 19:42:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('881', '3', '43', '20000', '200', '2019-12-23', '2019-12-23 19:43:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('882', '6', '43', '30000', '600', '2019-12-23', '2019-12-23 19:43:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('883', '7', '43', '30000', '300', '2019-12-23', '2019-12-23 19:43:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('884', '5', '43', '20000', '400', '2019-12-23', '2019-12-23 19:43:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('885', '11', '43', '20000', '400', '2019-12-23', '2019-12-23 19:44:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('886', '8', '43', '50000', '1500', '2019-12-23', '2019-12-23 19:44:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('887', '16', '43', '10000', '1000', '2019-12-23', '2019-12-23 19:44:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('888', '19', '43', '10000', '200', '2019-12-23', '2019-12-23 19:45:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('889', '20', '43', '20000', '600', '2019-12-23', '2019-12-23 19:45:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('890', '1', '43', '50000', '500', '2019-12-24', '2019-12-26 18:56:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('891', '10', '43', '20000', '200', '2019-12-24', '2019-12-26 18:56:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('892', '4', '43', '20000', '200', '2019-12-24', '2019-12-26 18:57:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('893', '6', '43', '30000', '300', '2019-12-24', '2019-12-26 18:57:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('894', '7', '43', '30000', '300', '2019-12-24', '2019-12-26 18:57:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('895', '5', '43', '20000', '200', '2019-12-24', '2019-12-26 18:57:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('896', '8', '43', '50000', '2000', '2019-12-24', '2019-12-26 18:58:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('897', '19', '43', '10000', '100', '2019-12-24', '2019-12-26 18:58:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('898', '20', '43', '20000', '200', '2019-12-24', '2019-12-26 18:58:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('899', '1', '43', '50000', '500', '2019-12-26', '2019-12-26 18:59:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('900', '10', '43', '20000', '400', '2019-12-26', '2019-12-26 18:59:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('901', '4', '43', '20000', '400', '2019-12-26', '2019-12-26 18:59:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('902', '17', '43', '50000', '5000', '2019-12-26', '2019-12-26 19:00:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('903', '3', '43', '20000', '400', '2019-12-26', '2019-12-26 19:00:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('904', '6', '43', '30000', '600', '2019-12-26', '2019-12-26 19:05:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('905', '7', '43', '30000', '300', '2019-12-26', '2019-12-26 19:05:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('906', '5', '43', '20000', '400', '2019-12-26', '2019-12-26 19:05:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('907', '11', '43', '20000', '400', '2019-12-26', '2019-12-26 19:05:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('908', '19', '43', '10000', '100', '2019-12-26', '2019-12-26 19:05:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('909', '20', '43', '20000', '400', '2019-12-26', '2019-12-26 19:05:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('910', '1', '43', '50000', '10000', '2019-12-27', '2019-12-27 19:26:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('911', '4', '43', '20000', '400', '2019-12-27', '2019-12-27 19:41:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('912', '17', '43', '50000', '1000', '2019-12-27', '2019-12-27 19:41:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('913', '3', '43', '20000', '400', '2019-12-27', '2019-12-27 19:42:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('914', '6', '43', '30000', '300', '2019-12-27', '2019-12-27 19:42:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('915', '5', '43', '20000', '200', '2019-12-27', '2019-12-27 19:42:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('916', '11', '43', '20000', '400', '2019-12-27', '2019-12-27 19:42:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('917', '8', '43', '50000', '4000', '2019-12-27', '2019-12-27 19:43:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('918', '19', '43', '10000', '100', '2019-12-27', '2019-12-27 19:43:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('919', '20', '43', '20000', '200', '2019-12-27', '2019-12-27 19:43:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('920', '7', '43', '30000', '300', '2019-12-27', '2019-12-27 19:44:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('921', '21', '43', '100000', '1000', '2019-12-28', '2019-12-28 20:36:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('922', '4', '43', '20000', '200', '2019-12-28', '2019-12-28 20:36:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('923', '17', '43', '50000', '500', '2019-12-28', '2019-12-28 20:37:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('924', '3', '43', '20000', '400', '2019-12-28', '2019-12-28 20:37:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('925', '6', '43', '30000', '300', '2019-12-28', '2019-12-28 20:37:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('926', '7', '43', '30000', '300', '2019-12-28', '2019-12-28 20:37:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('927', '5', '43', '20000', '200', '2019-12-28', '2019-12-28 20:37:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('928', '8', '43', '50000', '3000', '2019-12-28', '2019-12-28 20:38:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('929', '16', '43', '10000', '200', '2019-12-28', '2019-12-28 20:38:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('930', '19', '43', '10000', '100', '2019-12-28', '2019-12-28 20:38:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('931', '20', '43', '20000', '200', '2019-12-28', '2019-12-28 20:38:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('932', '21', '43', '100000', '1000', '2019-12-29', '2019-12-29 19:45:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('933', '4', '43', '20000', '200', '2019-12-29', '2019-12-29 19:45:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('934', '17', '43', '50000', '500', '2019-12-29', '2019-12-29 19:45:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('935', '6', '43', '30000', '300', '2019-12-29', '2019-12-29 19:46:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('936', '7', '43', '30000', '300', '2019-12-29', '2019-12-29 19:46:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('937', '15', '43', '30000', '1500', '2019-12-29', '2019-12-29 19:46:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('938', '19', '43', '10000', '100', '2019-12-29', '2019-12-29 19:46:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('939', '21', '43', '100000', '1000', '2019-12-30', '2019-12-30 22:48:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('940', '17', '43', '50000', '500', '2019-12-30', '2019-12-30 22:48:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('941', '14', '43', '30000', '600', '2019-12-30', '2019-12-30 22:48:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('942', '3', '43', '20000', '400', '2019-12-30', '2019-12-30 22:48:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('943', '6', '43', '30000', '300', '2019-12-30', '2019-12-30 22:48:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('944', '7', '43', '30000', '300', '2019-12-30', '2019-12-30 22:49:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('945', '5', '43', '20000', '400', '2019-12-30', '2019-12-30 22:49:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('946', '19', '43', '10000', '100', '2019-12-30', '2019-12-30 22:49:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('947', '20', '43', '20000', '400', '2019-12-30', '2019-12-30 22:49:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('948', '21', '43', '100000', '1000', '2019-12-31', '2019-12-31 19:23:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('949', '4', '43', '20000', '200', '2019-12-31', '2019-12-31 19:24:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('950', '14', '43', '30000', '600', '2019-12-31', '2019-12-31 19:24:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('951', '3', '43', '20000', '400', '2019-12-31', '2019-12-31 19:24:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('952', '6', '43', '30000', '300', '2019-12-31', '2019-12-31 19:24:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('953', '7', '43', '30000', '300', '2019-12-31', '2019-12-31 19:25:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('954', '5', '43', '20000', '200', '2019-12-31', '2019-12-31 19:25:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('955', '11', '43', '20000', '600', '2019-12-31', '2019-12-31 19:25:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('956', '8', '43', '50000', '500', '2019-12-31', '2019-12-31 19:25:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('957', '19', '43', '10000', '100', '2019-12-31', '2019-12-31 19:25:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('958', '20', '43', '20000', '200', '2019-12-31', '2019-12-31 19:25:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('959', '4', '43', '20000', '400', '2020-01-02', '2020-01-02 21:55:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('960', '21', '43', '100000', '1000', '2020-01-02', '2020-01-02 21:55:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('961', '19', '43', '10000', '200', '2020-01-02', '2020-01-02 21:56:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('962', '17', '43', '50000', '500', '2020-01-02', '2020-01-02 21:56:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('963', '20', '43', '20000', '400', '2020-01-02', '2020-01-02 21:56:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('964', '14', '43', '30000', '600', '2020-01-02', '2020-01-02 21:56:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('965', '3', '43', '20000', '400', '2020-01-02', '2020-01-02 21:57:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('966', '6', '43', '30000', '600', '2020-01-02', '2020-01-02 21:57:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('967', '7', '43', '30000', '300', '2020-01-02', '2020-01-02 21:57:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('968', '5', '43', '20000', '200', '2020-01-02', '2020-01-02 21:57:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('969', '11', '43', '20000', '200', '2020-01-02', '2020-01-02 21:58:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('970', '8', '43', '50000', '500', '2020-01-02', '2020-01-02 21:58:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('971', '16', '43', '10000', '400', '2020-01-02', '2020-01-02 21:58:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('972', '21', '43', '100000', '1000', '2020-01-03', '2020-01-04 21:44:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('973', '13', '43', '10000', '500', '2020-01-03', '2020-01-04 21:44:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('974', '4', '43', '20000', '200', '2020-01-03', '2020-01-04 21:45:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('975', '17', '43', '50000', '1000', '2020-01-03', '2020-01-04 21:45:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('976', '14', '43', '30000', '600', '2020-01-03', '2020-01-04 21:45:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('977', '3', '43', '20000', '400', '2020-01-03', '2020-01-04 21:46:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('978', '6', '43', '30000', '300', '2020-01-03', '2020-01-04 21:46:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('979', '7', '43', '30000', '600', '2020-01-03', '2020-01-04 21:46:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('980', '5', '43', '20000', '200', '2020-01-03', '2020-01-04 21:46:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('981', '11', '43', '20000', '200', '2020-01-03', '2020-01-04 21:47:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('982', '19', '43', '10000', '100', '2020-01-03', '2020-01-04 21:47:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('983', '20', '43', '20000', '200', '2020-01-03', '2020-01-04 21:47:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('984', '8', '43', '50000', '500', '2020-01-04', '2020-01-04 21:48:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('985', '4', '43', '20000', '200', '2020-01-04', '2020-01-04 21:48:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('986', '17', '43', '50000', '500', '2020-01-04', '2020-01-04 21:48:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('987', '14', '43', '30000', '600', '2020-01-04', '2020-01-04 21:55:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('988', '3', '43', '20000', '400', '2020-01-04', '2020-01-04 21:56:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('989', '6', '43', '30000', '300', '2020-01-04', '2020-01-04 21:56:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('990', '7', '43', '30000', '300', '2020-01-04', '2020-01-04 21:56:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('991', '5', '43', '20000', '200', '2020-01-04', '2020-01-04 21:56:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('992', '19', '43', '10000', '100', '2020-01-04', '2020-01-04 21:57:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('993', '20', '43', '20000', '200', '2020-01-04', '2020-01-04 21:58:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('994', '21', '43', '100000', '1000', '2020-01-04', '2020-01-04 21:59:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('995', '8', '43', '50000', '1000', '2020-01-04', '2020-01-07 21:04:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('996', '17', '43', '50000', '500', '2020-01-05', '2020-01-07 21:05:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('997', '14', '43', '30000', '600', '2020-01-05', '2020-01-07 21:06:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('998', '6', '43', '30000', '300', '2020-01-05', '2020-01-07 21:06:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('999', '7', '43', '30000', '300', '2020-01-05', '2020-01-07 21:06:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1000', '19', '43', '10000', '100', '2020-01-05', '2020-01-07 21:06:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1001', '21', '43', '100000', '2000', '2020-01-06', '2020-01-07 21:08:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1002', '4', '43', '20000', '200', '2020-01-06', '2020-01-07 21:08:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1003', '17', '43', '50000', '500', '2020-01-06', '2020-01-07 21:08:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1004', '3', '43', '20000', '200', '2020-01-06', '2020-01-07 21:08:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1005', '6', '43', '30000', '300', '2020-01-06', '2020-01-07 21:09:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1006', '7', '43', '30000', '300', '2020-01-06', '2020-01-07 21:09:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1007', '5', '43', '20000', '200', '2020-01-06', '2020-01-07 21:09:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1008', '15', '43', '30000', '2100', '2020-01-06', '2020-01-07 21:09:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1009', '16', '43', '10000', '500', '2020-01-06', '2020-01-07 21:10:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1010', '19', '43', '10000', '100', '2020-01-06', '2020-01-07 21:10:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1011', '20', '43', '20000', '400', '2020-01-06', '2020-01-07 21:10:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1012', '21', '43', '100000', '1000', '2020-01-07', '2020-01-07 21:11:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1013', '4', '43', '20000', '200', '2020-01-07', '2020-01-07 21:12:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1014', '17', '43', '50000', '500', '2020-01-07', '2020-01-07 21:12:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1015', '14', '43', '30000', '600', '2020-01-07', '2020-01-07 21:12:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1016', '3', '43', '20000', '400', '2020-01-07', '2020-01-07 21:12:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1017', '6', '43', '30000', '300', '2020-01-07', '2020-01-07 21:13:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1018', '7', '43', '30000', '300', '2020-01-07', '2020-01-07 21:13:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1019', '19', '43', '10000', '100', '2020-01-07', '2020-01-07 21:13:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1020', '20', '43', '20000', '200', '2020-01-07', '2020-01-07 21:13:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1021', '4', '43', '20000', '200', '2020-01-08', '2020-01-08 22:32:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1022', '17', '43', '50000', '500', '2020-01-08', '2020-01-08 22:33:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1023', '14', '43', '30000', '600', '2020-01-08', '2020-01-08 22:34:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1024', '3', '43', '20000', '200', '2020-01-08', '2020-01-08 22:34:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1025', '6', '43', '30000', '900', '2020-01-08', '2020-01-08 22:34:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1026', '7', '43', '30000', '300', '2020-01-08', '2020-01-08 22:35:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1027', '5', '43', '20000', '200', '2020-01-08', '2020-01-08 22:35:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1028', '19', '43', '10000', '100', '2020-01-08', '2020-01-08 22:35:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1029', '20', '43', '20000', '200', '2020-01-08', '2020-01-08 22:35:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1032', '21', '43', '100000', '1000', '2020-01-09', '2020-01-09 21:46:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1033', '13', '43', '10000', '1000', '2020-01-09', '2020-01-09 21:47:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1034', '4', '43', '20000', '200', '2020-01-09', '2020-01-09 21:47:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1035', '17', '43', '50000', '500', '2020-01-09', '2020-01-09 21:47:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1036', '14', '43', '30000', '600', '2020-01-09', '2020-01-09 21:47:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1037', '22', '43', '50000', '1000', '2020-01-09', '2020-01-09 21:48:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1038', '7', '43', '30000', '300', '2020-01-09', '2020-01-09 21:48:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1039', '5', '43', '20000', '1600', '2020-01-09', '2020-01-09 21:48:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1040', '19', '43', '10000', '100', '2020-01-09', '2020-01-09 21:49:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1041', '20', '43', '20000', '200', '2020-01-09', '2020-01-09 21:49:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1042', '21', '43', '100000', '1000', '2020-01-10', '2020-01-10 21:48:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1043', '4', '43', '20000', '200', '2020-01-10', '2020-01-10 21:48:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1044', '17', '43', '50000', '500', '2020-01-10', '2020-01-10 21:48:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1045', '14', '43', '30000', '600', '2020-01-10', '2020-01-10 21:48:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1046', '22', '43', '50000', '1000', '2020-01-10', '2020-01-10 21:49:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1047', '7', '43', '30000', '300', '2020-01-10', '2020-01-10 21:49:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1048', '19', '43', '10000', '100', '2020-01-10', '2020-01-10 21:49:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1049', '20', '43', '20000', '200', '2020-01-10', '2020-01-10 21:49:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1050', '21', '43', '100000', '1000', '2020-01-11', '2020-01-11 22:55:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1051', '13', '43', '10000', '500', '2020-01-11', '2020-01-11 22:55:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1052', '4', '43', '20000', '200', '2020-01-11', '2020-01-11 22:55:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1053', '17', '43', '50000', '500', '2020-01-11', '2020-01-11 22:56:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1054', '14', '43', '30000', '300', '2020-01-11', '2020-01-11 22:56:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1055', '22', '43', '50000', '1000', '2020-01-11', '2020-01-11 22:56:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1056', '7', '43', '30000', '300', '2020-01-11', '2020-01-11 22:57:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1057', '5', '43', '20000', '200', '2020-01-11', '2020-01-11 22:57:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1058', '19', '43', '10000', '200', '2020-01-11', '2020-01-11 22:57:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1060', '19', '43', '10000', '100', '2020-01-11', '2020-01-11 22:57:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1061', '21', '43', '100000', '1000', '2020-01-13', '2020-01-13 20:27:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1062', '4', '43', '20000', '400', '2020-01-13', '2020-01-13 20:28:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1063', '17', '43', '50000', '1000', '2020-01-13', '2020-01-13 20:28:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1064', '14', '43', '30000', '600', '2020-01-13', '2020-01-13 20:28:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1065', '22', '43', '50000', '2000', '2020-01-13', '2020-01-13 20:29:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1066', '7', '43', '30000', '600', '2020-01-13', '2020-01-13 20:29:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1067', '11', '43', '20000', '1000', '2020-01-13', '2020-01-13 20:29:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1068', '16', '43', '10000', '200', '2020-01-13', '2020-01-13 20:30:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1069', '19', '43', '10000', '200', '2020-01-13', '2020-01-13 20:30:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1070', '20', '43', '20000', '400', '2020-01-13', '2020-01-13 20:30:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1071', '21', '43', '100000', '1000', '2020-01-14', '2020-01-14 20:46:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1072', '4', '43', '20000', '400', '2020-01-14', '2020-01-14 20:47:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1073', '17', '43', '50000', '500', '2020-01-14', '2020-01-14 20:47:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1074', '14', '43', '30000', '600', '2020-01-14', '2020-01-14 20:48:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1075', '22', '43', '50000', '1000', '2020-01-14', '2020-01-14 20:56:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1076', '7', '43', '30000', '1500', '2020-01-14', '2020-01-14 20:57:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1077', '5', '43', '20000', '1200', '2020-01-14', '2020-01-14 20:57:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1078', '11', '43', '20000', '400', '2020-01-14', '2020-01-14 20:57:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1079', '19', '43', '10000', '100', '2020-01-14', '2020-01-14 20:58:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1080', '20', '43', '20000', '200', '2020-01-14', '2020-01-14 20:58:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1081', '23', '43', '10000', '100', '2020-01-14', '2020-01-14 21:01:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1082', '21', '43', '100000', '1000', '2020-01-15', '2020-01-16 16:49:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1083', '4', '43', '20000', '200', '2020-01-15', '2020-01-16 16:49:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1084', '17', '43', '50000', '500', '2020-01-15', '2020-01-16 16:49:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1085', '14', '43', '30000', '600', '2020-01-15', '2020-01-16 16:50:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1086', '22', '43', '50000', '1000', '2020-01-15', '2020-01-16 16:50:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1087', '7', '43', '30000', '600', '2020-01-15', '2020-01-16 16:50:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1088', '23', '43', '10000', '100', '2020-01-15', '2020-01-16 16:50:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1089', '16', '43', '10000', '300', '2020-01-15', '2020-01-16 16:51:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1090', '19', '43', '10000', '100', '2020-01-15', '2020-01-16 16:51:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1091', '20', '43', '20000', '200', '2020-01-15', '2020-01-16 16:51:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1092', '4', '43', '20000', '600', '2020-01-16', '2020-01-16 21:02:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1093', '17', '43', '50000', '500', '2020-01-16', '2020-01-16 21:02:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1094', '14', '43', '30000', '600', '2020-01-16', '2020-01-16 21:02:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1095', '22', '43', '50000', '1000', '2020-01-16', '2020-01-16 21:02:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1096', '7', '43', '30000', '600', '2020-01-16', '2020-01-16 21:03:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1097', '11', '43', '20000', '600', '2020-01-16', '2020-01-16 21:03:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1098', '19', '43', '10000', '100', '2020-01-16', '2020-01-16 21:03:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1099', '20', '43', '20000', '200', '2020-01-16', '2020-01-16 21:04:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1100', '17', '43', '50000', '500', '2020-01-17', '2020-01-17 22:31:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1101', '14', '43', '30000', '300', '2020-01-17', '2020-01-17 22:31:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1102', '22', '43', '50000', '1000', '2020-01-17', '2020-01-17 22:32:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1103', '23', '43', '10000', '100', '2020-01-17', '2020-01-17 22:32:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1104', '11', '43', '20000', '600', '2020-01-17', '2020-01-17 22:32:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1105', '2', '43', '20000', '3600', '2020-01-17', '2020-01-17 22:33:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1106', '16', '43', '10000', '100', '2020-01-17', '2020-01-17 22:33:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1107', '19', '43', '10000', '100', '2020-01-17', '2020-01-17 22:34:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1108', '20', '43', '20000', '200', '2020-01-17', '2020-01-17 22:34:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1109', '14', '43', '30000', '600', '2020-01-18', '2020-01-20 21:44:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1110', '22', '43', '50000', '1000', '2020-01-18', '2020-01-20 21:44:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1111', '19', '43', '10000', '100', '2020-01-18', '2020-01-20 21:44:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1112', '20', '43', '20000', '200', '2020-01-18', '2020-01-20 21:44:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1113', '10', '43', '20000', '1000', '2020-01-19', '2020-01-20 21:45:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1114', '13', '43', '10000', '600', '2020-01-19', '2020-01-20 21:45:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1115', '17', '43', '50000', '1000', '2020-01-19', '2020-01-20 21:45:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1116', '14', '43', '30000', '300', '2020-01-19', '2020-01-20 21:45:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1117', '22', '43', '50000', '1000', '2020-01-19', '2020-01-20 21:46:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1118', '19', '43', '10000', '100', '2020-01-19', '2020-01-20 21:46:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1119', '20', '43', '20000', '200', '2020-01-19', '2020-01-20 21:46:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1120', '10', '43', '20000', '600', '2020-01-20', '2020-01-20 21:46:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1121', '17', '43', '50000', '500', '2020-01-20', '2020-01-20 21:47:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1122', '14', '43', '30000', '600', '2020-01-20', '2020-01-20 21:47:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1123', '22', '43', '50000', '1000', '2020-01-20', '2020-01-20 21:47:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1124', '19', '43', '10000', '100', '2020-01-20', '2020-01-20 21:47:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1125', '20', '43', '20000', '200', '2020-01-20', '2020-01-20 21:47:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1126', '23', '43', '10000', '200', '2020-01-20', '2020-01-20 21:48:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1127', '10', '43', '20000', '600', '2020-01-21', '2020-01-21 22:45:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1128', '17', '43', '50000', '500', '2020-01-21', '2020-01-21 22:45:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1129', '14', '43', '30000', '600', '2020-01-21', '2020-01-21 22:45:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1130', '22', '43', '50000', '1000', '2020-01-21', '2020-01-21 22:45:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1131', '19', '43', '10000', '100', '2020-01-21', '2020-01-21 22:45:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1132', '20', '43', '20000', '200', '2020-01-21', '2020-01-21 22:46:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1133', '23', '43', '10000', '100', '2020-01-21', '2020-01-21 22:46:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1134', '24', '43', '30000', '300', '2020-01-21', '2020-01-21 22:46:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1135', '10', '43', '20000', '200', '2020-01-23', '2020-01-24 00:22:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1136', '17', '43', '50000', '500', '2020-01-23', '2020-01-24 00:22:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1137', '14', '43', '30000', '600', '2020-01-23', '2020-01-24 00:22:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1138', '22', '43', '50000', '1000', '2020-01-23', '2020-01-24 00:23:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1139', '19', '43', '10000', '100', '2020-01-23', '2020-01-24 00:23:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1140', '20', '43', '20000', '200', '2020-01-23', '2020-01-24 00:23:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1141', '23', '43', '10000', '100', '2020-01-23', '2020-01-24 00:23:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1142', '24', '43', '30000', '300', '2020-01-23', '2020-01-24 00:23:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1143', '10', '43', '20000', '200', '2020-01-22', '2020-01-24 00:27:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1144', '13', '43', '10000', '200', '2020-01-22', '2020-01-24 00:27:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1145', '14', '43', '30000', '600', '2020-01-22', '2020-01-24 00:27:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1146', '22', '43', '50000', '1000', '2020-01-22', '2020-01-24 00:28:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1147', '19', '43', '10000', '100', '2020-01-22', '2020-01-24 00:28:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1148', '20', '43', '20000', '200', '2020-01-22', '2020-01-24 00:28:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1149', '23', '43', '10000', '100', '2020-01-22', '2020-01-24 00:29:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1150', '24', '43', '30000', '300', '2020-01-22', '2020-01-24 00:29:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1151', '10', '43', '20000', '200', '2020-01-24', '2020-01-24 22:01:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1152', '17', '43', '50000', '500', '2020-01-24', '2020-01-24 22:02:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1153', '14', '43', '30000', '600', '2020-01-24', '2020-01-24 22:02:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1154', '22', '43', '50000', '1000', '2020-01-24', '2020-01-24 22:02:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1155', '19', '43', '10000', '100', '2020-01-24', '2020-01-24 22:02:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1156', '20', '43', '20000', '200', '2020-01-24', '2020-01-24 22:03:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1157', '23', '43', '10000', '100', '2020-01-24', '2020-01-24 22:03:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1158', '15', '43', '30000', '5000', '2020-01-24', '2020-01-24 22:03:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1159', '24', '43', '30000', '300', '2020-01-24', '2020-01-24 22:04:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1160', '10', '43', '20000', '200', '2020-01-25', '2020-01-25 21:40:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1161', '17', '43', '50000', '500', '2020-01-25', '2020-01-25 21:40:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1162', '22', '43', '50000', '1000', '2020-01-25', '2020-01-25 21:41:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1163', '19', '43', '10000', '100', '2020-01-25', '2020-01-25 21:41:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1164', '20', '43', '20000', '200', '2020-01-25', '2020-01-25 21:41:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1165', '23', '43', '10000', '100', '2020-01-25', '2020-01-25 21:41:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1166', '11', '43', '20000', '400', '2020-01-25', '2020-01-25 21:42:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1167', '24', '43', '30000', '300', '2020-01-25', '2020-01-25 21:42:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1168', '10', '43', '20000', '400', '2020-01-26', '2020-01-26 20:48:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1169', '13', '43', '10000', '100', '2020-01-26', '2020-01-26 20:48:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1170', '14', '43', '30000', '600', '2020-01-26', '2020-01-26 20:49:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1171', '22', '43', '50000', '1000', '2020-01-26', '2020-01-26 20:49:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1172', '19', '43', '10000', '100', '2020-01-26', '2020-01-26 20:49:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1173', '24', '43', '30000', '300', '2020-01-26', '2020-01-26 20:49:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1174', '10', '43', '20000', '200', '2020-01-27', '2020-01-27 20:39:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1176', '13', '43', '10000', '100', '2020-01-27', '2020-01-27 20:39:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1177', '17', '43', '50000', '500', '2020-01-27', '2020-01-27 20:40:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1178', '14', '43', '30000', '600', '2020-01-27', '2020-01-27 20:40:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1179', '22', '43', '50000', '1000', '2020-01-27', '2020-01-27 20:40:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1180', '19', '43', '10000', '100', '2020-01-27', '2020-01-27 20:40:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1181', '20', '43', '20000', '200', '2020-01-27', '2020-01-27 20:42:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1182', '23', '43', '10000', '100', '2020-01-27', '2020-01-27 20:42:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1183', '24', '43', '30000', '300', '2020-01-27', '2020-01-27 20:42:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1184', '10', '43', '20000', '200', '2020-01-28', '2020-01-28 21:49:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1185', '13', '43', '10000', '500', '2020-01-28', '2020-01-28 21:49:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1186', '17', '43', '50000', '500', '2020-01-28', '2020-01-28 21:49:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1187', '14', '43', '30000', '600', '2020-01-28', '2020-01-28 21:50:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1188', '22', '43', '50000', '1000', '2020-01-28', '2020-01-28 21:50:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1189', '19', '43', '10000', '100', '2020-01-28', '2020-01-28 21:50:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1190', '20', '43', '20000', '200', '2020-01-28', '2020-01-28 21:50:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1191', '23', '43', '10000', '100', '2020-01-28', '2020-01-28 21:50:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1192', '24', '43', '30000', '300', '2020-01-28', '2020-01-28 21:51:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1193', '10', '43', '20000', '200', '2020-01-29', '2020-01-29 22:08:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1194', '17', '43', '50000', '500', '2020-01-29', '2020-01-29 22:08:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1195', '14', '43', '30000', '300', '2020-01-29', '2020-01-29 22:08:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1196', '22', '43', '50000', '1000', '2020-01-29', '2020-01-29 22:09:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1197', '19', '43', '10000', '100', '2020-01-29', '2020-01-29 22:10:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1198', '20', '43', '20000', '200', '2020-01-29', '2020-01-29 22:10:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1199', '23', '43', '10000', '9800', '2020-01-29', '2020-01-29 22:13:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1200', '24', '43', '30000', '300', '2020-01-29', '2020-01-29 22:14:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1201', '23', '43', '10000', '1000', '2020-01-29', '2020-01-29 22:41:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1202', '10', '43', '20000', '400', '2020-01-30', '2020-01-30 21:41:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1203', '13', '43', '10000', '100', '2020-01-30', '2020-01-30 21:41:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1204', '17', '43', '50000', '500', '2020-01-30', '2020-01-30 21:41:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1205', '14', '43', '30000', '600', '2020-01-30', '2020-01-30 21:42:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1206', '22', '43', '50000', '1000', '2020-01-30', '2020-01-30 21:42:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1207', '19', '43', '10000', '100', '2020-01-30', '2020-01-30 21:42:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1208', '20', '43', '20000', '200', '2020-01-30', '2020-01-30 21:42:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1209', '24', '43', '30000', '300', '2020-01-30', '2020-01-30 21:42:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1210', '10', '43', '20000', '200', '2020-01-31', '2020-01-31 22:32:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1211', '13', '43', '10000', '100', '2020-01-31', '2020-01-31 22:32:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1212', '17', '43', '50000', '500', '2020-01-31', '2020-01-31 22:32:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1213', '14', '43', '30000', '600', '2020-01-31', '2020-01-31 22:33:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1214', '22', '43', '50000', '1000', '2020-01-31', '2020-01-31 22:33:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1215', '19', '43', '10000', '100', '2020-01-31', '2020-01-31 22:33:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1216', '20', '43', '20000', '200', '2020-01-31', '2020-01-31 22:33:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1217', '11', '43', '20000', '2000', '2020-01-31', '2020-01-31 22:33:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1218', '24', '43', '30000', '300', '2020-01-31', '2020-01-31 22:34:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1219', '10', '43', '20000', '200', '2020-02-02', '2020-02-02 01:36:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1220', '13', '43', '10000', '100', '2020-02-01', '2020-02-02 01:37:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1221', '17', '43', '50000', '500', '2020-02-01', '2020-02-02 01:37:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1222', '14', '43', '30000', '600', '2020-02-01', '2020-02-02 01:37:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1223', '22', '43', '50000', '1000', '2020-02-01', '2020-02-02 01:37:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1224', '19', '43', '10000', '100', '2020-02-01', '2020-02-02 01:38:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1225', '20', '43', '20000', '200', '2020-02-01', '2020-02-02 01:38:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1226', '24', '43', '30000', '300', '2020-02-01', '2020-02-02 01:38:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1227', '10', '43', '20000', '200', '2020-02-03', '2020-02-03 21:59:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1228', '13', '43', '10000', '200', '2020-02-03', '2020-02-03 21:59:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1229', '17', '43', '50000', '1000', '2020-02-03', '2020-02-03 22:00:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1230', '14', '43', '30000', '600', '2020-02-03', '2020-02-03 22:00:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1231', '22', '43', '50000', '2000', '2020-02-03', '2020-02-03 22:00:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1232', '20', '43', '20000', '200', '2020-02-03', '2020-02-03 22:00:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1233', '24', '43', '30000', '600', '2020-02-03', '2020-02-03 22:01:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1234', '10', '43', '20000', '200', '2020-02-04', '2020-02-05 19:56:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1235', '17', '43', '50000', '500', '2020-02-04', '2020-02-05 19:56:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1236', '14', '43', '30000', '600', '2020-02-04', '2020-02-05 19:57:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1237', '22', '43', '50000', '1000', '2020-02-04', '2020-02-05 19:57:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1238', '20', '43', '20000', '200', '2020-02-04', '2020-02-05 19:57:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1239', '24', '43', '30000', '300', '2020-02-04', '2020-02-05 19:57:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1240', '10', '43', '20000', '200', '2020-02-05', '2020-02-05 19:58:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1241', '13', '43', '10000', '200', '2020-02-05', '2020-02-05 19:58:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1242', '17', '43', '50000', '500', '2020-02-05', '2020-02-05 19:58:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1243', '14', '43', '30000', '300', '2020-02-05', '2020-02-05 19:59:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1244', '22', '43', '50000', '1000', '2020-02-05', '2020-02-05 19:59:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1245', '19', '43', '10000', '400', '2020-02-05', '2020-02-05 19:59:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1246', '20', '43', '20000', '200', '2020-02-05', '2020-02-05 19:59:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1247', '24', '43', '30000', '300', '2020-02-05', '2020-02-05 19:59:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1248', '25', '43', '50000', '1000', '2020-02-05', '2020-02-05 20:06:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1249', '9', '43', '10000', '5700', '2020-02-06', '2020-02-06 21:06:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1250', '10', '43', '20000', '200', '2020-02-06', '2020-02-06 21:09:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1251', '17', '43', '50000', '500', '2020-02-06', '2020-02-06 21:09:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1252', '14', '43', '30000', '300', '2020-02-06', '2020-02-06 21:09:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1253', '22', '43', '50000', '1000', '2020-02-06', '2020-02-06 21:09:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1254', '19', '43', '10000', '100', '2020-02-06', '2020-02-06 21:10:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1255', '20', '43', '20000', '200', '2020-02-06', '2020-02-06 21:10:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1256', '24', '43', '30000', '300', '2020-02-06', '2020-02-06 21:10:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1257', '25', '43', '50000', '1000', '2020-02-06', '2020-02-06 21:10:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1258', '10', '43', '20000', '200', '2020-02-07', '2020-02-09 14:06:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1259', '13', '43', '10000', '200', '2020-02-07', '2020-02-09 14:06:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1260', '17', '43', '50000', '500', '2020-02-07', '2020-02-09 14:07:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1261', '14', '43', '30000', '300', '2020-02-07', '2020-02-09 14:07:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1262', '22', '43', '50000', '1000', '2020-02-07', '2020-02-09 14:07:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1263', '19', '43', '10000', '100', '2020-02-07', '2020-02-09 14:07:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1264', '20', '43', '20000', '200', '2020-02-07', '2020-02-09 14:07:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1265', '11', '43', '20000', '1000', '2020-02-07', '2020-02-09 14:07:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1266', '24', '43', '30000', '300', '2020-02-07', '2020-02-09 14:08:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1267', '25', '43', '50000', '1000', '2020-02-07', '2020-02-09 14:08:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1268', '10', '43', '20000', '200', '2020-02-08', '2020-02-09 22:26:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1269', '22', '43', '50000', '1000', '2020-02-08', '2020-02-09 22:27:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1270', '19', '43', '10000', '100', '2020-02-08', '2020-02-09 22:27:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1271', '20', '43', '20000', '200', '2020-02-08', '2020-02-09 22:27:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1273', '24', '43', '30000', '300', '2020-02-08', '2020-02-09 22:28:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1274', '24', '43', '30000', '300', '2020-02-08', '2020-02-09 22:28:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1275', '25', '43', '50000', '1000', '2020-02-08', '2020-02-09 22:28:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1276', '25', '43', '50000', '1000', '2020-02-09', '2020-02-09 22:29:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1277', '22', '43', '50000', '1000', '2020-02-09', '2020-02-09 22:30:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1278', '17', '43', '50000', '500', '2020-02-09', '2020-02-09 22:30:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1279', '10', '43', '20000', '200', '2020-02-09', '2020-02-09 22:30:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1280', '10', '43', '20000', '200', '2020-02-10', '2020-02-10 23:26:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1281', '13', '43', '10000', '300', '2020-02-10', '2020-02-10 23:26:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1282', '17', '43', '50000', '1000', '2020-02-10', '2020-02-10 23:26:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1283', '22', '43', '50000', '1000', '2020-02-10', '2020-02-10 23:26:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1284', '19', '43', '10000', '200', '2020-02-10', '2020-02-10 23:27:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1285', '20', '43', '20000', '200', '2020-02-10', '2020-02-10 23:27:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1286', '11', '43', '20000', '1000', '2020-02-10', '2020-02-10 23:27:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1287', '24', '43', '30000', '300', '2020-02-10', '2020-02-10 23:27:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1288', '25', '43', '50000', '1000', '2020-02-10', '2020-02-10 23:27:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1289', '10', '43', '20000', '200', '2020-02-11', '2020-02-11 22:44:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1290', '17', '43', '50000', '500', '2020-02-11', '2020-02-11 22:44:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1291', '22', '43', '50000', '1000', '2020-02-11', '2020-02-11 22:44:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1292', '19', '43', '10000', '100', '2020-02-11', '2020-02-11 22:44:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1293', '20', '43', '20000', '200', '2020-02-11', '2020-02-11 22:45:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1294', '11', '43', '20000', '1400', '2020-02-11', '2020-02-11 22:45:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1295', '24', '43', '30000', '300', '2020-02-11', '2020-02-11 22:45:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1296', '25', '43', '50000', '1000', '2020-02-11', '2020-02-11 22:45:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1297', '10', '43', '20000', '200', '2020-02-12', '2020-02-12 21:40:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1298', '17', '43', '50000', '1000', '2020-02-12', '2020-02-12 21:40:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1299', '22', '43', '50000', '1000', '2020-02-12', '2020-02-12 21:40:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1300', '19', '43', '10000', '100', '2020-02-12', '2020-02-12 21:41:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1301', '20', '43', '20000', '200', '2020-02-12', '2020-02-12 21:41:14');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1302', '11', '43', '20000', '600', '2020-02-12', '2020-02-12 21:41:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1303', '24', '43', '30000', '300', '2020-02-12', '2020-02-12 21:42:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1304', '25', '43', '50000', '1000', '2020-02-12', '2020-02-12 21:42:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1305', '17', '43', '50000', '500', '2020-02-13', '2020-02-15 04:53:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1306', '22', '43', '50000', '1000', '2020-02-13', '2020-02-15 04:53:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1307', '19', '43', '10000', '100', '2020-02-13', '2020-02-15 04:54:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1308', '20', '43', '20000', '200', '2020-02-13', '2020-02-15 04:54:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1309', '11', '43', '20000', '1000', '2020-02-13', '2020-02-15 04:54:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1310', '24', '43', '30000', '300', '2020-02-13', '2020-02-15 04:55:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1311', '25', '43', '50000', '1000', '2020-02-13', '2020-02-15 04:55:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1312', '10', '43', '20000', '400', '2020-02-14', '2020-02-15 04:57:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1313', '13', '43', '10000', '200', '2020-02-14', '2020-02-15 04:58:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1314', '17', '43', '50000', '500', '2020-02-14', '2020-02-15 04:58:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1315', '22', '43', '50000', '1000', '2020-02-14', '2020-02-15 04:58:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1316', '19', '43', '10000', '100', '2020-02-14', '2020-02-15 04:58:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1317', '20', '43', '20000', '200', '2020-02-14', '2020-02-15 04:58:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1319', '24', '43', '30000', '300', '2020-02-14', '2020-02-15 04:59:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1320', '25', '43', '50000', '1000', '2020-02-14', '2020-02-15 04:59:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1321', '16', '43', '10000', '1000', '2020-02-14', '2020-02-15 05:03:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1322', '10', '43', '20000', '200', '2020-02-15', '2020-02-16 18:55:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1323', '13', '43', '10000', '100', '2020-02-15', '2020-02-16 18:55:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1324', '17', '43', '50000', '500', '2020-02-15', '2020-02-16 18:55:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1325', '22', '43', '50000', '1000', '2020-02-15', '2020-02-16 18:56:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1326', '19', '43', '10000', '100', '2020-02-15', '2020-02-16 18:56:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1327', '20', '43', '20000', '200', '2020-02-15', '2020-02-16 18:56:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1328', '24', '43', '30000', '300', '2020-02-15', '2020-02-16 18:56:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1329', '25', '43', '50000', '1000', '2020-02-15', '2020-02-16 18:57:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1330', '10', '43', '20000', '200', '2020-02-16', '2020-02-16 18:57:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1331', '13', '43', '10000', '100', '2020-02-16', '2020-02-16 18:58:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1332', '17', '43', '50000', '500', '2020-02-16', '2020-02-16 18:58:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1333', '14', '43', '30000', '600', '2020-02-16', '2020-02-16 18:58:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1335', '22', '43', '50000', '1000', '2020-02-16', '2020-02-16 18:58:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1336', '24', '43', '30000', '300', '2020-02-16', '2020-02-16 18:58:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1337', '19', '43', '10000', '100', '2020-02-16', '2020-02-16 18:59:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1338', '20', '43', '20000', '200', '2020-02-16', '2020-02-16 18:59:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1339', '25', '43', '50000', '1000', '2020-02-16', '2020-02-16 18:59:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1340', '10', '43', '20000', '200', '2020-02-17', '2020-02-18 05:36:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1341', '17', '43', '50000', '500', '2020-02-17', '2020-02-18 05:37:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1342', '14', '43', '30000', '600', '2020-02-17', '2020-02-18 05:37:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1343', '22', '43', '50000', '1000', '2020-02-17', '2020-02-18 05:37:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1344', '24', '43', '30000', '300', '2020-02-17', '2020-02-18 05:37:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1345', '19', '43', '10000', '100', '2020-02-17', '2020-02-18 05:37:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1346', '20', '43', '20000', '200', '2020-02-17', '2020-02-18 05:37:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1347', '26', '43', '20000', '400', '2020-02-17', '2020-02-18 05:38:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1348', '15', '43', '30000', '3000', '2020-02-17', '2020-02-18 05:38:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1349', '25', '43', '50000', '1000', '2020-02-17', '2020-02-18 05:38:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1350', '10', '43', '20000', '200', '2020-02-18', '2020-02-19 00:09:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1351', '17', '43', '50000', '500', '2020-02-18', '2020-02-19 00:09:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1352', '14', '43', '30000', '600', '2020-02-18', '2020-02-19 00:09:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1353', '22', '43', '50000', '1000', '2020-02-18', '2020-02-19 00:09:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1354', '24', '43', '30000', '300', '2020-02-18', '2020-02-19 00:09:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1355', '19', '43', '10000', '100', '2020-02-18', '2020-02-19 00:09:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1356', '20', '43', '20000', '200', '2020-02-18', '2020-02-19 00:10:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1357', '25', '43', '50000', '1000', '2020-02-18', '2020-02-19 00:10:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1358', '10', '43', '20000', '200', '2020-02-19', '2020-02-19 22:52:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1359', '13', '43', '10000', '700', '2020-02-19', '2020-02-19 22:52:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1360', '17', '43', '50000', '500', '2020-02-19', '2020-02-19 22:52:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1361', '14', '43', '30000', '600', '2020-02-19', '2020-02-19 22:52:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1362', '22', '43', '50000', '1000', '2020-02-19', '2020-02-19 22:53:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1363', '24', '43', '30000', '300', '2020-02-19', '2020-02-19 22:53:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1364', '19', '43', '10000', '100', '2020-02-19', '2020-02-19 22:53:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1365', '20', '43', '20000', '200', '2020-02-19', '2020-02-19 22:53:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1366', '26', '43', '20000', '600', '2020-02-19', '2020-02-19 22:53:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1367', '25', '43', '50000', '1000', '2020-02-19', '2020-02-19 22:54:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1372', '10', '43', '20000', '200', '2020-02-21', '2020-02-21 23:36:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1373', '17', '43', '50000', '500', '2020-02-21', '2020-02-21 23:36:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1374', '14', '43', '30000', '600', '2020-02-21', '2020-02-21 23:36:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1375', '22', '43', '50000', '1000', '2020-02-21', '2020-02-21 23:36:32');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1376', '24', '43', '30000', '300', '2020-02-21', '2020-02-21 23:36:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1377', '19', '43', '10000', '100', '2020-02-21', '2020-02-21 23:36:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1378', '20', '43', '20000', '200', '2020-02-21', '2020-02-21 23:36:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1379', '26', '43', '20000', '400', '2020-02-21', '2020-02-21 23:37:10');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1380', '25', '43', '50000', '1000', '2020-02-21', '2020-02-21 23:37:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1381', '10', '43', '20000', '200', '2020-02-20', '2020-02-21 23:38:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1382', '17', '43', '50000', '500', '2020-02-20', '2020-02-21 23:38:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1383', '14', '43', '30000', '600', '2020-02-20', '2020-02-21 23:38:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1384', '22', '43', '30000', '1000', '2020-02-20', '2020-02-21 23:39:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1385', '24', '43', '30000', '300', '2020-02-20', '2020-02-21 23:39:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1386', '19', '43', '10000', '100', '2020-02-20', '2020-02-21 23:39:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1387', '20', '43', '10000', '200', '2020-02-20', '2020-02-21 23:39:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1388', '25', '43', '50000', '1000', '2020-02-20', '2020-02-21 23:39:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1390', '17', '43', '50000', '500', '2020-02-22', '2020-02-25 16:34:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1392', '22', '43', '50000', '1000', '2020-02-22', '2020-02-25 16:35:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1393', '24', '43', '30000', '300', '2020-02-22', '2020-02-25 16:35:12');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1394', '19', '43', '10000', '100', '2020-02-22', '2020-02-25 16:35:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1395', '20', '43', '20000', '200', '2020-02-22', '2020-02-25 16:35:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1397', '25', '43', '50000', '1000', '2020-02-22', '2020-02-25 16:36:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1398', '10', '43', '20000', '200', '2020-02-22', '2020-02-25 16:38:27');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1399', '14', '43', '30000', '2400', '2020-02-22', '2020-02-25 16:38:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1400', '10', '43', '20000', '200', '2020-02-22', '2020-02-25 16:40:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1401', '10', '43', '20000', '200', '2020-02-23', '2020-02-25 20:31:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1402', '17', '43', '50000', '500', '2020-02-23', '2020-02-25 20:31:22');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1403', '27', '43', '30000', '600', '2020-02-23', '2020-02-25 20:36:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1404', '22', '43', '50000', '1000', '2020-02-23', '2020-02-25 20:36:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1405', '24', '43', '30000', '300', '2020-02-23', '2020-02-25 20:36:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1406', '19', '43', '10000', '100', '2020-02-23', '2020-02-25 20:36:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1407', '20', '43', '20000', '200', '2020-02-23', '2020-02-25 20:37:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1408', '25', '43', '50000', '1000', '2020-02-23', '2020-02-25 20:37:21');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1409', '10', '43', '20000', '200', '2020-02-24', '2020-02-25 20:37:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1410', '17', '43', '50000', '500', '2020-02-24', '2020-02-25 20:38:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1411', '27', '43', '30000', '300', '2020-02-24', '2020-02-25 20:38:11');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1412', '22', '43', '50000', '1000', '2020-02-24', '2020-02-25 20:38:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1413', '24', '43', '30000', '300', '2020-02-24', '2020-02-25 20:38:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1414', '19', '43', '10000', '100', '2020-02-24', '2020-02-25 20:38:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1415', '20', '43', '20000', '200', '2020-02-24', '2020-02-25 20:38:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1416', '26', '43', '20000', '200', '2020-02-24', '2020-02-25 20:39:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1417', '25', '43', '50000', '1000', '2020-02-24', '2020-02-25 20:39:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1418', '13', '43', '10000', '200', '2020-02-25', '2020-02-25 20:40:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1419', '17', '43', '50000', '500', '2020-02-25', '2020-02-25 20:40:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1420', '27', '43', '30000', '300', '2020-02-25', '2020-02-25 20:40:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1421', '22', '43', '50000', '1000', '2020-02-25', '2020-02-25 20:41:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1422', '24', '43', '30000', '300', '2020-02-25', '2020-02-25 20:41:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1423', '19', '43', '10000', '100', '2020-02-25', '2020-02-25 20:41:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1424', '20', '43', '20000', '200', '2020-02-25', '2020-02-25 20:41:35');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1426', '25', '43', '50000', '1000', '2020-02-25', '2020-02-25 20:42:31');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1427', '14', '43', '30000', '600', '2020-02-22', '2020-02-25 21:05:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1428', '10', '43', '20000', '400', '2020-02-24', '2020-02-25 21:05:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1429', '13', '43', '10000', '200', '2020-02-26', '2020-02-27 15:10:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1430', '17', '43', '50000', '500', '2020-02-26', '2020-02-27 15:10:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1431', '27', '43', '30000', '600', '2020-02-26', '2020-02-27 15:10:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1432', '22', '43', '50000', '1000', '2020-02-26', '2020-02-27 15:11:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1433', '24', '43', '30000', '300', '2020-02-26', '2020-02-27 15:11:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1434', '19', '43', '10000', '100', '2020-02-26', '2020-02-27 15:11:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1435', '20', '43', '20000', '200', '2020-02-26', '2020-02-27 15:11:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1436', '25', '43', '50000', '1000', '2020-02-26', '2020-02-27 15:12:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1437', '17', '43', '50000', '500', '2020-02-27', '2020-02-27 21:48:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1438', '27', '43', '30000', '600', '2020-02-27', '2020-02-27 21:48:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1439', '22', '43', '50000', '1000', '2020-02-27', '2020-02-27 21:49:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1440', '24', '43', '30000', '300', '2020-02-27', '2020-02-27 21:49:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1441', '19', '43', '10000', '100', '2020-02-27', '2020-02-27 21:49:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1443', '20', '43', '20000', '200', '2020-02-27', '2020-02-27 21:49:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1444', '25', '43', '50000', '1000', '2020-02-27', '2020-02-27 21:49:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1445', '13', '43', '10000', '800', '2020-02-28', '2020-03-01 23:33:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1446', '17', '43', '50000', '500', '2020-02-28', '2020-03-01 23:34:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1447', '27', '43', '30000', '600', '2020-02-28', '2020-03-01 23:34:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1448', '22', '43', '50000', '1000', '2020-02-28', '2020-03-01 23:34:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1449', '24', '43', '30000', '300', '2020-02-28', '2020-03-01 23:34:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1450', '19', '43', '10000', '100', '2020-02-28', '2020-03-01 23:34:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1451', '20', '43', '20000', '200', '2020-02-28', '2020-03-01 23:34:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1452', '25', '43', '50000', '1000', '2020-02-28', '2020-03-01 23:35:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1453', '17', '43', '50000', '500', '2020-02-29', '2020-03-01 23:35:23');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1454', '27', '43', '30000', '600', '2020-02-29', '2020-03-01 23:35:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1455', '22', '43', '50000', '1000', '2020-02-29', '2020-03-01 23:35:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1456', '24', '43', '30000', '300', '2020-02-29', '2020-03-01 23:35:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1457', '19', '43', '10000', '100', '2020-02-29', '2020-03-01 23:36:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1458', '20', '43', '20000', '200', '2020-02-29', '2020-03-01 23:36:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1459', '25', '43', '50000', '1000', '2020-02-29', '2020-03-01 23:36:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1460', '27', '43', '30000', '600', '2020-03-01', '2020-03-01 23:37:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1461', '22', '43', '50000', '1000', '2020-03-01', '2020-03-01 23:37:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1462', '24', '43', '30000', '300', '2020-03-01', '2020-03-01 23:37:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1463', '19', '43', '10000', '100', '2020-03-01', '2020-03-01 23:37:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1464', '20', '43', '20000', '200', '2020-03-01', '2020-03-01 23:37:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1465', '25', '43', '50000', '1000', '2020-03-01', '2020-03-01 23:38:05');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1469', '22', '43', '50000', '1000', '2020-03-02', '2020-03-02 22:15:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1471', '24', '43', '30000', '300', '2020-03-02', '2020-03-02 22:15:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1472', '19', '43', '10000', '100', '2020-03-02', '2020-03-02 22:16:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1473', '20', '43', '20000', '200', '2020-03-02', '2020-03-02 22:16:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1475', '25', '43', '50000', '1000', '2020-03-02', '2020-03-02 22:16:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1476', '27', '43', '30000', '600', '2020-03-02', '2020-03-02 22:20:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1477', '17', '43', '50000', '1500', '2020-03-02', '2020-03-02 22:20:30');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1478', '17', '43', '50000', '1000', '2020-03-03', '2020-03-04 03:09:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1479', '22', '43', '50000', '1000', '2020-03-03', '2020-03-04 03:09:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1480', '24', '43', '30000', '300', '2020-03-03', '2020-03-04 03:09:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1481', '20', '43', '20000', '200', '2020-03-03', '2020-03-04 03:09:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1482', '26', '43', '20000', '400', '2020-03-03', '2020-03-04 03:10:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1483', '25', '43', '50000', '1000', '2020-03-03', '2020-03-04 03:10:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1484', '19', '43', '10000', '100', '2020-03-03', '2020-03-04 03:10:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1485', '17', '43', '50000', '500', '2020-03-04', '2020-03-04 22:05:38');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1486', '24', '43', '30000', '300', '2020-03-04', '2020-03-04 22:05:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1487', '20', '43', '20000', '200', '2020-03-04', '2020-03-04 22:06:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1488', '25', '43', '50000', '1000', '2020-03-04', '2020-03-04 22:06:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1489', '19', '43', '10000', '100', '2020-03-04', '2020-03-04 22:06:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1490', '17', '43', '50000', '500', '2020-03-05', '2020-03-05 22:00:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1491', '24', '43', '30000', '300', '2020-03-05', '2020-03-05 22:01:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1492', '20', '43', '20000', '200', '2020-03-05', '2020-03-05 22:01:39');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1493', '25', '43', '50000', '1000', '2020-03-05', '2020-03-05 22:01:56');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1494', '19', '43', '10000', '100', '2020-03-05', '2020-03-05 22:02:15');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1495', '28', '43', '10000', '100', '2020-03-05', '2020-03-05 22:09:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1496', '22', '43', '50000', '5000', '2020-03-05', '2020-03-05 22:17:49');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1497', '17', '43', '50000', '500', '2020-03-06', '2020-03-06 23:54:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1498', '24', '43', '30000', '300', '2020-03-06', '2020-03-06 23:55:07');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1499', '20', '43', '20000', '200', '2020-03-06', '2020-03-06 23:55:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1500', '26', '43', '20000', '1000', '2020-03-06', '2020-03-06 23:56:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1501', '25', '43', '50000', '1000', '2020-03-06', '2020-03-06 23:56:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1502', '19', '43', '10000', '100', '2020-03-06', '2020-03-06 23:56:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1503', '28', '43', '10000', '100', '2020-03-06', '2020-03-06 23:56:52');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1504', '17', '43', '50000', '500', '2020-03-07', '2020-03-08 14:55:37');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1505', '24', '43', '30000', '300', '2020-03-07', '2020-03-08 14:55:47');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1506', '20', '43', '20000', '200', '2020-03-07', '2020-03-08 14:55:55');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1507', '25', '43', '50000', '1000', '2020-03-07', '2020-03-08 14:56:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1508', '19', '43', '10000', '100', '2020-03-07', '2020-03-08 14:56:19');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1509', '28', '43', '10000', '100', '2020-03-07', '2020-03-08 14:56:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1510', '15', '43', '30000', '15300', '2020-03-08', '2020-03-08 15:50:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1512', '17', '43', '50000', '500', '2020-03-08', '2020-03-09 00:27:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1513', '24', '43', '30000', '300', '2020-03-08', '2020-03-09 00:27:28');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1514', '19', '43', '10000', '100', '2020-03-08', '2020-03-09 00:27:44');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1515', '28', '43', '10000', '100', '2020-03-08', '2020-03-09 00:27:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1516', '20', '43', '20000', '200', '2020-03-08', '2020-03-09 00:28:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1517', '25', '43', '50000', '1000', '2020-03-08', '2020-03-09 00:28:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1518', '29', '43', '100000', '1000', '2020-03-08', '2020-03-09 00:32:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1519', '17', '43', '50000', '500', '2020-03-09', '2020-03-10 04:46:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1520', '29', '43', '100000', '1000', '2020-03-09', '2020-03-10 04:46:20');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1521', '24', '43', '30000', '300', '2020-03-09', '2020-03-10 04:46:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1522', '19', '43', '10000', '100', '2020-03-09', '2020-03-10 04:46:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1523', '28', '43', '10000', '100', '2020-03-09', '2020-03-10 04:46:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1524', '25', '43', '50000', '1000', '2020-03-09', '2020-03-10 04:47:08');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1525', '17', '43', '50000', '500', '2020-03-10', '2020-03-10 21:57:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1526', '29', '43', '100000', '1000', '2020-03-10', '2020-03-10 21:58:00');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1527', '24', '43', '30000', '300', '2020-03-10', '2020-03-10 21:58:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1528', '19', '43', '10000', '100', '2020-03-10', '2020-03-10 21:58:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1529', '28', '43', '10000', '100', '2020-03-10', '2020-03-10 21:58:24');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1530', '20', '43', '20000', '200', '2020-03-10', '2020-03-10 21:58:33');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1531', '26', '43', '20000', '400', '2020-03-10', '2020-03-10 21:58:45');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1532', '25', '43', '50000', '1000', '2020-03-10', '2020-03-10 21:58:57');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1533', '17', '43', '50000', '500', '2020-03-11', '2020-03-11 18:57:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1534', '19', '43', '10000', '100', '2020-03-11', '2020-03-11 18:57:26');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1535', '28', '43', '10000', '100', '2020-03-11', '2020-03-11 18:57:34');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1536', '29', '43', '100000', '1000', '2020-03-11', '2020-03-11 18:57:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1537', '24', '43', '30000', '300', '2020-03-11', '2020-03-11 18:57:50');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1538', '25', '43', '50000', '1000', '2020-03-11', '2020-03-11 18:58:01');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1539', '17', '43', '50000', '500', '2020-03-12', '2020-03-12 21:13:13');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1540', '27', '43', '30000', '600', '2020-03-12', '2020-03-12 21:13:41');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1541', '29', '43', '100000', '1000', '2020-03-12', '2020-03-12 21:13:53');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1542', '24', '43', '30000', '300', '2020-03-12', '2020-03-12 21:14:02');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1543', '19', '43', '10000', '100', '2020-03-12', '2020-03-12 21:14:09');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1544', '28', '43', '10000', '100', '2020-03-12', '2020-03-12 21:14:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1545', '26', '43', '20000', '400', '2020-03-12', '2020-03-12 21:14:29');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1546', '16', '43', '10000', '900', '2020-03-12', '2020-03-12 21:14:43');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1547', '25', '43', '50000', '1000', '2020-03-12', '2020-03-12 21:14:54');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1548', '30', '43', '10000', '300', '2020-03-12', '2020-03-12 21:15:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1549', '17', '43', '50000', '500', '2020-03-13', '2020-03-13 21:05:40');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1550', '27', '43', '30000', '600', '2020-03-13', '2020-03-13 21:05:59');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1551', '29', '43', '100000', '1000', '2020-03-13', '2020-03-13 21:06:42');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1552', '24', '43', '30000', '300', '2020-03-13', '2020-03-13 21:07:06');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1553', '19', '43', '10000', '100', '2020-03-13', '2020-03-13 21:07:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1554', '28', '43', '10000', '100', '2020-03-13', '2020-03-13 21:07:25');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1555', '20', '43', '20000', '600', '2020-03-13', '2020-03-13 21:07:46');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1556', '25', '43', '50000', '1000', '2020-03-13', '2020-03-13 21:08:04');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1557', '30', '43', '10000', '100', '2020-03-13', '2020-03-13 21:08:18');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1558', '17', '43', '50000', '500', '2020-03-14', '2020-03-14 21:25:51');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1559', '27', '43', '30000', '300', '2020-03-14', '2020-03-14 21:26:03');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1560', '29', '43', '100000', '1000', '2020-03-14', '2020-03-14 21:26:17');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1561', '24', '43', '30000', '300', '2020-03-14', '2020-03-14 21:26:36');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1562', '19', '43', '10000', '100', '2020-03-14', '2020-03-14 21:26:48');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1563', '28', '43', '10000', '100', '2020-03-14', '2020-03-14 21:26:58');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1564', '25', '43', '50000', '1000', '2020-03-14', '2020-03-14 21:27:16');
INSERT INTO `tbl_pay` (`pay_id`, `loan_id`, `collector_id`, `loanamt`, `pay_loan_amt`, `loandate`, `timestamp`) VALUES ('1565', '30', '43', '10000', '100', '2020-03-14', '2020-03-14 21:27:27');


#
# TABLE STRUCTURE FOR: tbl_reg
#

DROP TABLE IF EXISTS `tbl_reg`;

CREATE TABLE `tbl_reg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(222) DEFAULT NULL,
  `contact` varchar(222) DEFAULT NULL,
  `address` varchar(222) DEFAULT NULL,
  `state` varchar(222) DEFAULT NULL,
  `gender` varchar(222) DEFAULT NULL,
  `email` varchar(222) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(222) DEFAULT '3',
  `is_active` varchar(255) NOT NULL DEFAULT '0',
  `is_coll_assign` int(11) DEFAULT NULL,
  `is_delete` int(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('1', 'Admin', 'Xdbs', '1234567890', 'Pune', 'maharashtra', 'male', 'abcd@gmail.com', 'admin', '53756d6d6572403030', '1', '1', NULL, '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('40', 'Avee', 'sfjh', '12223', 'sdfdsdf', '231dsg32', 'sd3fg', 'sdf', 'Avee', '31323334', '0', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('41', 'AVEE', 'Roto', '7770001515', 'pune', 'Maharashtra', 'Femal', 'aveeroto@gmail.com', 'aveeroto', '61766565726f746f', '0', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('42', 'Soma', 'Roto', '4567890678', 'Ziro', 'AP', 'Female', '', 'soma', '736f6d61', '0', '1', '44', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('43', 'Asha', 'Asha', '1234123412', 'asha', 'asha', 'female', 'test@test.com', 'Asha', '41736861', '2', '1', NULL, '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('44', 'Yari', 'Yari', '1234123412', 'Yari', 'test', 'female', 'Yari@test.com', 'Yari', '59617269', '2', '1', NULL, '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('45', 'Anya', 'Roto', '7798361700', 'quarry Line', 'ARUNACHAL PRADESH', 'Female', '', 'anyaroto', '616e7961726f746f', '0', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('46', 'Yabo', 'Yabo', '', '', '', '', '', 'Yabo', '5961626f40333333', '2', '1', NULL, '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('47', ' Jugi', ' Yajen ', ' 8131847637', '   Police Colony', '    ARUNACHAL PRADESH', '  Female', '    ', ' Jugi', '204a756769', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('48', ' Jainath', ' Prasad', ' 8794253055', ' Club Road', ' ARUNACHAL PRADESH', ' Male', ' ', ' Jainath', '204a61696e617468', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('49', 'Hibu', 'Yassung', '8415000787', 'S.P. Colony', 'Arunachal Pradesh', 'Female', '', 'Yassung', '59617373756e67', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('50', 'Madhav Sinha ', 'Munna', '8794756670', 'Pai Gate', 'ARUNACHAL PRADESH', 'Male', '', 'Madhav', '4d6164686176', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('51', 'superadmin', 'superadmin', '1234567890', 'Pune', 'maharashtra', 'male', 'abcd@gmail.com', 'superadmin', '31323334', '1', '1', NULL, '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('52', 'Krishna ', 'Chetry', '8794386677', 'Reserve Line', 'ARUNACHAL PRADESH', 'Male', '', 'Krishna', '4b726973686e61', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('53', 'Radhika', 'Kala Baido', '9774043629', 'Tempo Station', 'ARUNACHAL PRADESH', 'Female', '', 'Radhika', '52616468696b61', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('54', 'Ige ', 'Lingo', '8794636680', 'Tempo Station', 'ARUNACHAL PRADESH', 'Male', '', 'Ige', '496765', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('55', 'Bibhuchandra ', 'Singah', '9383370346', 'quarry Line', 'Arunachal Pradesh', 'Male', '', 'Bibhuchandra', '42696268756368616e647261', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('56', 'Shanti ', 'Dorjee', '7030649130', 'Club road ', 'Aruncahal Pradesh', 'Female ', '', 'Shanti', '5368616e7469', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('57', 'Tadu ', 'Rillung', '8794331581', 'Tempo Station', 'ARUNACHAL PRADESH', 'Female', '', 'Rillung', '52696c6c756e67', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('58', '   Goper', '   Riba', '9774039046', '   Pai Gate', '   ARUNACHAL PRADESH', '   Female', '   ', '   Goper', '202020476f706572', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('59', ' Balika', 'Darji', '  7030649130', '  PAI GATE', '  ARUNACHAL PRADESH', '  Female', '  ', '  Balika', '202042616c696b61', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('60', 'Chandra ', 'Bahadur', '9774910839', 'Paigate ', 'Hapoli', 'Male', '', 'Chandra', '4368616e647261', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('61', 'Nani ', 'Oniya', '7640092260', 'Pai Gate', 'ARUNACHAL PRADESH', 'Female', '', 'Oniya', '4f6e697961', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('62', 'Avi', 'Roto', '8258837249', 'School Gate', 'ARUNACHAL PRADESH', 'Female', '', 'Avi', '417669', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('65', 'Likha', 'Yapi', '7085124427', 'Reserve line ', 'AP', 'Female', '', 'Lakhi', '4c616b6869', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('70', 'Sanu', 'Limbu', '9999999999', 'Reserve line', 'ARUNACHAL PRADESH', 'Female', '', 'Sanu', '53616e75', '3', '1', '43', '0');
INSERT INTO `tbl_reg` (`id`, `fname`, `lname`, `contact`, `address`, `state`, `gender`, `email`, `username`, `password`, `type`, `is_active`, `is_coll_assign`, `is_delete`) VALUES ('71', 'Noor', 'Ali', '8135803444', 'quarry Line', 'Arunachal', 'male', '', 'Noor', '4e6f6f72', '3', '1', '43', '0');


#
# TABLE STRUCTURE FOR: tbl_total_addcapital
#

DROP TABLE IF EXISTS `tbl_total_addcapital`;

CREATE TABLE `tbl_total_addcapital` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `total_amount` varchar(250) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_total_addcapital` (`id`, `total_amount`, `timestamp`) VALUES ('1', '0', '2019-12-04 15:56:37');


#
# TABLE STRUCTURE FOR: tbl_upcoming_report
#

DROP TABLE IF EXISTS `tbl_upcoming_report`;

CREATE TABLE `tbl_upcoming_report` (
  `tbl_upcoming_report_id` int(250) NOT NULL AUTO_INCREMENT,
  `date` varchar(250) DEFAULT NULL,
  `custone_id` int(250) DEFAULT NULL,
  `customer_name` varchar(250) DEFAULT NULL,
  `loan_id` varchar(50) DEFAULT NULL,
  `loan_amount` varchar(50) DEFAULT NULL,
  `interest` varchar(50) DEFAULT NULL,
  `daily_target` varchar(250) DEFAULT NULL,
  `collected_amount` varchar(50) DEFAULT NULL,
  `remaining_amount` varchar(50) DEFAULT NULL,
  `days_left` varchar(250) DEFAULT NULL,
  `aprx_date` varchar(250) DEFAULT NULL,
  `cash_in_bank` varchar(255) DEFAULT NULL,
  `to_makeup` varchar(250) DEFAULT NULL,
  `month_avg` varchar(250) DEFAULT NULL,
  `apox_days_to_save` varchar(250) DEFAULT NULL,
  `gap` varchar(250) DEFAULT NULL,
  `project_1` varchar(250) DEFAULT NULL,
  `project_2` varchar(255) DEFAULT NULL,
  `tbl_upcoming_report_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tbl_upcoming_report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('1', '09/04/2019', '48', 'Jainath Prasad', '1', '50000', '10000', '500', '60000', '0', '0', '2020-03-16', '0', '50000', '4829', '10', '18337', '2020-03-06', '2020-03-06', '2019-09-27 20:39:04');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('2', '09/05/2019', '49', 'Hibu Yassung', '2', '20000', '4000', '200', '24000', '0', '0', '2020-03-16', '0', '20000', '4829', '4', '0', '2020-03-12', '1969-12-28', '2019-09-27 20:41:51');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('3', '09/10/2019', '50', 'Madhav Sinha Munna', '3', '20000', '4000', '200', '24000', '0', '0', '2020-03-16', '0', '20000', '4829', '4', '0', '2020-03-12', '1969-12-28', '2019-09-27 20:43:04');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('4', '09/12/2019', '52', 'Krishna  Chetry', '4', '20000', '4000', '200', '24000', '0', '0', '2020-03-16', '0', '20000', '4829', '4', '0', '2020-03-12', '1969-12-28', '2019-09-27 20:44:23');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('5', '09/12/2019', '53', 'Radhika Kala Baido', '5', '20000', '4000', '200', '24000', '0', '0', '2020-03-16', '0', '20000', '4829', '4', '0', '2020-03-12', '1969-12-28', '2019-09-27 20:45:38');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('6', '09/13/2019', '54', 'Ige  Lingo', '6', '30000', '6000', '300', '36000', '0', '0', '2020-03-16', '0', '30000', '4829', '6', '0', '2020-03-10', '1969-12-26', '2019-09-27 20:47:23');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('7', '09/19/2019', '47', 'Jugi Yajen', '7', '30000', '6000', '300', '36000', '0', '0', '2020-03-16', '0', '30000', '4829', '6', '0', '2020-03-10', '1969-12-26', '2019-09-27 20:48:19');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('8', '10/01/2019', '55', 'Bibhuchandra  Singah', '8', '50000', '10000', '500', '60000', '0', '0', '2020-03-16', '0', '50000', '4829', '10', '0', '2020-03-06', '1969-12-22', '2019-10-01 23:50:32');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('9', '10/14/2019', '49', 'Hibu Yassung', '9', '10000', '2000', '100', '12000', '0', '0', '2020-03-16', '0', '10000', '4829', '2', '0', '2020-03-14', '1969-12-30', '2019-10-14 19:34:17');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('10', '10/17/2019', '56', 'Shanti  Dorjee', '10', '20000', '4000', '200', '24000', '0', '0', '2020-03-16', '0', '20000', '4829', '4', '0', '2020-03-12', '1969-12-28', '2019-10-18 12:26:18');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('11', '10/24/2019', '57', 'Tadu  Rillung', '11', '20000', '4000', '200', '24000', '0', '0', '2020-03-16', '0', '20000', '4829', '4', '0', '2020-03-12', '1969-12-28', '2019-10-24 17:46:24');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('12', '10/31/2019', '58', 'Gopar Riba', '12', '20000', '4000', '200', '24000', '0', '0', '2020-03-16', '0', '20000', '4829', '4', '0', '2020-03-12', '1969-12-28', '2019-10-31 21:58:19');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('13', '11/11/2019', '59', 'BALIKA m', '13', '10000', '2000', '100', '12000', '0', '0', '2020-03-16', '0', '10000', '4829', '2', '0', '2020-03-14', '1969-12-30', '2019-11-11 23:26:29');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('14', '11/15/2019', '60', 'Chandra  Bahadur', '14', '30000', '6000', '300', '36000', '0', '0', '2020-03-16', '0', '30000', '4829', '6', '0', '2020-03-10', '1969-12-26', '2019-11-15 20:24:09');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('15', '11/28/2019', '61', 'Nani  Oniya', '15', '30000', '6000', '300', '31400', '4600', '15.333333333333334', '-256472427492-08-31', '47700', '-17700', '4829', '-4', '25202', '1970-01-01', '1970-01-01', '2019-11-28 18:58:41');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('16', '12/02/2019', '62', 'Avi Roto', '16', '10000', '2000', '100', '5000', '7000', '70', '2020-05-25', '0', '10000', '4829', '2', '4', '2020-05-23', '1970-01-03', '2019-12-02 18:03:15');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('17', '12/06/2019', '58', '   Goper    Riba', '17', '50000', '10000', '500', '49500', '10500', '21', '2020-04-06', '0', '50000', '4829', '10', '1', '2020-03-27', '1969-12-23', '2019-12-05 21:54:51');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('19', '12/11/2019', '65', 'Likha Yapi', '19', '10000', '2000', '100', '10000', '2000', '20', '2020-04-05', '0', '10000', '4829', '2', '20', '2020-04-03', '1970-01-19', '2019-12-09 22:14:28');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('20', '12/19/2019', '70', 'Sanu Limbu', '20', '20000', '4000', '200', '16000', '8000', '40', '2020-04-25', '0', '20000', '4829', '4', '19', '2020-04-21', '1970-01-16', '2019-12-20 21:39:45');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('21', '12/28/2019', '48', ' Jainath  Prasad', '21', '100000', '20000', '1000', '16000', '104000', '104', '2020-06-28', '0', '100000', '4829', '21', '3', '2020-06-07', '1969-12-14', '2019-12-27 19:28:18');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('22', '01/09/2020', '54', 'Ige  Lingo', '22', '50000', '10000', '500', '60000', '0', '0', '2020-03-16', '0', '50000', '4829', '10', '0', '2020-03-06', '1969-12-22', '2020-01-08 22:55:18');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('23', '01/14/2020', '53', 'Radhika Kala Baido', '23', '10000', '2000', '100', '12000', '0', '0', '2020-03-16', '0', '10000', '4829', '2', '0', '2020-03-14', '1969-12-30', '2020-01-14 21:00:44');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('24', '01/20/2020', '47', ' Jugi  Yajen ', '24', '30000', '6000', '300', '16200', '19800', '66', '2020-05-21', '0', '30000', '4829', '6', '24', '2020-05-15', '1970-01-19', '2020-01-20 21:51:29');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('25', '02/05/2020', '71', 'Noor Ali', '25', '50000', '10000', '500', '39000', '21000', '42', '2020-04-27', '0', '50000', '4829', '10', '2', '2020-04-17', '1969-12-24', '2020-02-05 20:02:24');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('26', '02/17/2020', '57', 'Tadu  Rillung', '26', '20000', '4000', '200', '3800', '20200', '101', '2020-06-25', '0', '20000', '4829', '4', '2', '2020-06-21', '1969-12-30', '2020-02-16 19:01:10');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('27', '02/23/2020', '60', 'Chandra  Bahadur', '27', '30000', '6000', '300', '6300', '29700', '99', '2020-06-23', '0', '30000', '4829', '6', '29', '2020-06-17', '1970-01-24', '2020-02-25 20:35:03');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('28', '03/05/2020', '65', 'Likha Yapi', '28', '10000', '2000', '100', '1000', '11000', '110', '2020-07-04', '0', '10000', '4829', '2', '6', '2020-07-02', '1970-01-05', '2020-03-05 22:09:17');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('29', '03/08/2020', '54', 'Ige  Lingo', '29', '100000', '20000', '1000', '7000', '113000', '113', '2020-07-07', '0', '100000', '4829', '21', '3', '2020-06-16', '1969-12-14', '2020-03-09 00:30:13');
INSERT INTO `tbl_upcoming_report` (`tbl_upcoming_report_id`, `date`, `custone_id`, `customer_name`, `loan_id`, `loan_amount`, `interest`, `daily_target`, `collected_amount`, `remaining_amount`, `days_left`, `aprx_date`, `cash_in_bank`, `to_makeup`, `month_avg`, `apox_days_to_save`, `gap`, `project_1`, `project_2`, `tbl_upcoming_report_timestamp`) VALUES ('30', '03/10/2020', '53', 'Radhika Kala Baido', '30', '10000', '2000', '100', '500', '11500', '115', '2020-07-09', '0', '10000', '4829', '2', '2', '2020-07-07', '1970-01-01', '2020-03-10 04:50:08');


